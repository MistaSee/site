# Source provenance — AdventureMaster

Packaged for Mark Calleja on 6 November 2026.

Source GPT: https://chatgpt.com/g/g-68de9a6eb420819197e909eb0f30e7eb

The prompt was copied from the author’s GPT configuration. Source text is preserved in system-prompt.md. The skill wrapper adds identifying metadata, reference links and host compatibility guidance. The original name, description, conversation starters and capability settings are recorded in original-configuration.json.

Knowledge attachments: 0. Original attachment bytes were checked against the export’s recorded size and SHA-256 hashes. Word document text copies are derived reading aids; the original files are retained.

Runs as a text adventure. Save and load use state snapshots in the conversation; keep a copy if you want to continue in another chat.

The package was structurally validated and its archive integrity checked. It has not been behaviour-tested on every model. Original claims, example quotations and bibliographies have not been independently fact-checked by this preservation pass. No new licence is asserted for Mark’s work; source documents retain their existing notices.
