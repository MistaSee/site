# Reference provenance

Packaged 6 November 2026. The PDFs are copied without changes. Original copyright and licence notices remain in each PDF.

## primary-curriculum.pdf

Full primary curriculum framework, including the subject programmes and English appendices.

Source: https://www.gov.uk/government/publications/national-curriculum-in-england-primary-curriculum

SHA-256: `9c03f311a342f3efe8569b74f4ff795a82ed72b23d8cfd6a4fe2551f702a3744`

## rshe-guidance-2026.pdf

Current relationships, sex and health education guidance. Use the primary sections for BrainBuddy.

Source: https://www.gov.uk/government/publications/relationships-education-relationships-and-sex-education-rse-and-health-education

SHA-256: `999203ab4db830c069ee3841920e6ab9d4a5a6d7c3195822700cc984a9239714`

## Licensing

Government PDFs retain their own Crown copyright and Open Government Licence notices. Mark Calleja is credited as the creator of these coaching prompts and author of the OCEAN paper. No additional licence is asserted for his work by this package.
