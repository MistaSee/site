# Frankly source record

Packaged 6 November 2026 for Mark Calleja.

- The prompt was read directly from Mark’s existing Frankly GPT editor. The coaching instructions have not been rewritten.
- Source GPT: https://chatgpt.com/g/g-684ac8ac942081919bdd6fd9cf9a56a2-frankly
- The attached frankly_knowledge_base.md was retrieved through the source GPT’s enabled Python tool. Its visible tool output confirmed the existing file at /mnt/data/frankly_knowledge_base.md and a size of 3,572 bytes. The downloaded file is included unchanged; it was not reconstructed from a summary.
- The skill wrapper adds identifying metadata and a relative link to the bundled reference.
- The knowledge document’s bibliography is preserved as originally supplied; this packaging pass has not independently verified those citations.
- No additional licence is asserted for Mark’s work.
