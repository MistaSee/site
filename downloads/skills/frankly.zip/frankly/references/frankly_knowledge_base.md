# Knowledge Reference for Frankly (Critical Friend Chatbot)

## Critical Thinking Frameworks

### Logical Fallacies
- **Straw man**: Misrepresenting opponent's argument.
- **Ad hominem**: Attacking the person rather than the argument.
- **Slippery slope**: Predicting extreme outcomes without evidence.
- **Hasty generalisation**: Drawing broad conclusions from limited evidence.

### Cognitive Biases
- **Confirmation bias**: Seeking only information supporting existing beliefs.
- **Anchoring bias**: Over-reliance on initial information.
- **Availability heuristic**: Overestimating importance based on recent memory.

### SWOT Analysis
- **Strengths**: Internal advantages.
- **Weaknesses**: Internal disadvantages.
- **Opportunities**: External beneficial factors.
- **Threats**: External detrimental factors.

## Constructive Feedback Techniques

### Giving Productive Critiques
- **Behaviour-focused**: Critique actions or content, not the person.
- **"I" statements**: Use statements like "I think..." to reduce defensiveness.
- **Specific and actionable**: Provide clear, practical suggestions.
- **Balanced feedback**: Include positives alongside critique.
- **Timely feedback**: Give feedback soon after relevant events.
- **Encourage dialogue**: Engage user with questions and empathy.

### Socratic Questioning Principles
- **Clarification**: "What do you mean by...?"
- **Assumptions**: "What assumptions underpin this viewpoint?"
- **Evidence**: "What evidence supports this?"
- **Alternative perspectives**: "How might others see this?"
- **Consequences**: "What if you're wrong?"
- **Questioning the question**: "Why is this question significant?"

## Decision-Making Strategies

### Decision Models
- **OODA Loop**: Observe, Orient, Decide, Act; iterative for rapid decisions.
- **DECIDE model**: Detect issue, Estimate urgency, Choose outcome, Identify solutions, Do actions, Evaluate results.

### Risk Assessment Basics
- **Identify risks**: List potential issues clearly.
- **Analyse risks**: Assess likelihood and impact.
- **Prioritise risks**: Rank based on significance.
- **Mitigate risks**: Plan to manage or reduce risks.
- **Monitor**: Regularly review risks and adjust.

## Basic Psychology & Social Dynamics

### Behavioural Economics Principles
- **Loss aversion**: Preferring to avoid losses over achieving gains.
- **Framing effect**: Decisions influenced by presentation.
- **Present bias**: Preferring immediate rewards over future benefits.

### Interpersonal Communication
- **Active listening**: Reflecting and clarifying user's statements.
- **Empathy and respect**: Recognising and validating user emotions.
- **Clarity and assertiveness**: Communicating clearly without aggression.
- **Open-ended questions**: Encouraging detailed responses.
- **Avoid assumptions**: Clarify unclear points explicitly.

### Emotional Intelligence
- **Self-awareness**: Understanding one's emotional state and biases.
- **Self-regulation**: Controlling emotional responses.
- **Empathy**: Understanding and sharing others' emotions.
- **Social skills**: Managing interactions effectively.
- **Motivation**: Encouraging intrinsic drive for positive outcomes.

---

### References:
- Purves, G., & Snell, R. (2023). *Artificial Intelligence as a Critical Friend*. HMC Blog.
- Galstyan, A. (2025). *Prompting ChatGPT for Critical Dialogue*. LinkedIn.
- Meller, W. (2025). *Effective Prompting Techniques*. Medium.
- Kahneman, D. (2011). *Thinking, Fast and Slow*. Penguin.
- Cialdini, R. B. (2001). *Influence: Science and Practice*. Allyn & Bacon.

