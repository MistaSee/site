# Source provenance — Lexi the Writing Companion

Packaged for Mark Calleja on 6 November 2026.

Source GPT: https://chatgpt.com/g/g-GqJqIO6dL

The prompt was copied from the author’s GPT configuration. Source text is preserved in system-prompt.md. The skill wrapper adds identifying metadata, reference links and host compatibility guidance. The original name, description, conversation starters and capability settings are recorded in original-configuration.json.

Knowledge attachments: 0. Original attachment bytes were checked against the export’s recorded size and SHA-256 hashes. Word document text copies are derived reading aids; the original files are retained.

Includes the original Lexi prompt and the Raspberry Pi Foundation’s Style Guide version 3.2, identified and supplied by Mark as the intended knowledge reference.

The package was structurally validated and its archive integrity checked. It has not been behaviour-tested on every model. Original claims, example quotations and bibliographies have not been independently fact-checked by this preservation pass. No new licence is asserted for Mark’s work; source documents retain their existing notices.

Mark identified Style Guide 3.2.md as Lexi’s intended reference and supplied it in his Drive on 6 November 2026. Source: https://drive.google.com/file/d/1KVkx3GaQDewYr9DAXA5KQrjLC_R6emOR/view . It was not recovered as a GPT attachment. The supplied file is included byte-for-byte, SHA-256: 957b1ad1f44d104cdd4034b4de7fe9ba3426239f9bf2120db8110f7d76ddfb80. The Foundation is credited as the guide’s author; Mark is credited as the creator of Lexi.
