# Source provenance — Lexi the Writing Companion

Packaged for Mark Calleja on 6 November 2026.

Source GPT: https://chatgpt.com/g/g-GqJqIO6dL

The prompt was copied from the author’s GPT configuration. Source text is preserved in system-prompt.md. The skill wrapper adds identifying metadata, reference links and host compatibility guidance. The original name, description, conversation starters and capability settings are recorded in original-configuration.json.

Knowledge attachments: 0. Original attachment bytes were checked against the export’s recorded size and SHA-256 hashes. Word document text copies are derived reading aids; the original files are retained.

The original prompt is included. Mark identified the RPF content style guide as its intended reference; that guide requires access and is not bundled. Attach an authorised copy before using guide-specific feedback.

The package was structurally validated and its archive integrity checked. It has not been behaviour-tested on every model. Original claims, example quotations and bibliographies have not been independently fact-checked by this preservation pass. No new licence is asserted for Mark’s work; source documents retain their existing notices.
