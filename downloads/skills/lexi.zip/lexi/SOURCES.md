# Source provenance — Lexi the Writing Companion

Packaged for Mark Calleja on 6 November 2026.

Source GPT: https://chatgpt.com/g/g-GqJqIO6dL

The prompt was copied from the author’s GPT configuration. Source text is preserved in original-system-prompt.md. The active system-prompt.md follows Mark’s new constitution. The skill wrapper adds identifying metadata, reference links and host compatibility guidance. The original name, description, conversation starters and capability settings are recorded in original-configuration.json.

Knowledge attachments: 0. Original attachment bytes were checked against the export’s recorded size and SHA-256 hashes. Word document text copies are derived reading aids; the original files are retained.

Governed by Lexi’s new constitution: questions and editorial tips, encouragement without flattery, and no writing or rewriting prose for the author.

The package was structurally validated and its archive integrity checked. It has not been behaviour-tested on every model. Original claims, example quotations and bibliographies have not been independently fact-checked by this preservation pass. No new licence is asserted for Mark’s work; source documents retain their existing notices.

Mark commissioned a new governing constitution for Lexi on 6 November 2026: coaching through questions and editorial tips, no authored or rewritten prose, and encouragement without sycophancy. He then instructed that the style guide be removed. The constitution is the sole active reference. The recovered GPT prompt is retained only as a historical source, not as overriding instructions.
