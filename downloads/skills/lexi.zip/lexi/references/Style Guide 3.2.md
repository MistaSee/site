# The Raspberry Pi Foundation’s Style Guide (version 3.2) 

# Table of contents {#table-of-contents}

[**Table of contents	1**](#table-of-contents)

[**Quick links to our resources	2**](#quick-links-to-our-resources)

[**Intro	3**](#intro)

[**Section 1 – Product-specific guidance	4**](#section-1-–-product-specific-guidance)

[Ada Computer Science \- Sarah	4](#ada-computer-science---sarah)

[Applied Certificate (updated Sept 2025\)	6](#applied-certificate-\(updated-sept-2025\))

[Astro Pi (updated Dec 2025\)	6](#astro-pi-\(updated-dec-2025\))

[UK Bebras Challenge	8](#uk-bebras-challenge)

[Code Club (updated Sept 2025\)	9](#code-club-\(updated-sept-2025\))

[Code Club Projects site \- Abi	14](#code-club-projects-site---abi)

[Code Editor \- Sarah	17](#code-editor---sarah)

[Coolest Projects \- Sarah	19](#coolest-projects---sarah)

[The Computing Curriculum \- Tom (low priority)	19](#the-computing-curriculum---tom-\(low-priority\))

[Experience AI (updated Sept 2025\)	22](#experience-ai-\(updated-sept-2025\))

[Experience CS	24](#experience-cs)

[Online courses (updated Sept 2025\)	27](#online-courses-\(updated-sept-2025\))

[Research \- Sarah	30](#research---sarah)

[Research to practice — Quick Reads	31](#research-to-practice-—-quick-reads)

[Training slide decks	31](#training-slide-decks)

[**Section 2 – Word list	32**](#section-2-–-word-list)

[**Section 3 – General guidance	1**](#section-3-–-general-guidance)

[Some quick do’s and don'ts	1](#some-quick-do’s-and-don'ts)

[Images	1](#images)

[Images of other companies’ brand assets	1](#images-of-other-companies’-brand-assets)

[Global resources and considerations	1](#global-resources-and-considerations)

[Links	1](#links)

[URLs	1](#urls)

[**Punctuation	1**](#punctuation)

[Hyphen (-):	1](#hyphen-\(-\):)

[En dash (–):	1](#en-dash-\(–\):)

[Em dash (—):	1](#em-dash-\(—\):)

[Quotation marks (' and "):	1](#quotation-marks-\('-and-"\):)

[Colon:	1](#colon:)

[Capitalisation	1](#capitalisation)

[Contractions	1](#contractions)

[**Formatting	1**](#formatting)

[Lists	1](#lists)

[Headings	1](#headings)

[Titles	1](#titles)

[Abbreviations	1](#abbreviations)

[**Numbers	1**](#numbers)

[General	1](#general)

[Binary	1](#binary)

[Units	1](#units)

[Time and date	1](#time-and-date)

[**References	1**](#references)

[**Referring to ourselves	1**](#referring-to-ourselves)

[The Raspberry Pi Foundation	1](#the-raspberry-pi-foundation)

[Our charitable status	1](#our-charitable-status)

[Raspberry Pi computers	1](#raspberry-pi-computers)

[**Links, misc., and useful info	1**](#links,-misc.,-and-useful-info)

[For reference	1](#for-reference)

[To resources regarding accessibility and inclusion	1](#to-resources-regarding-accessibility-and-inclusion)

[To individual articles on inclusive language:	1](#to-individual-articles-on-inclusive-language:)

# 

# Quick links to our resources {#quick-links-to-our-resources}

Other style guides

* [Short style guide for content creators](https://docs.google.com/document/d/1QdZlFGHv5L2pz40XcZ6BwMROQzEvHjuZRsoTXdizT8k/edit?pli=1#heading=h.jl5e019mabgr) (created Jan 2024\)  
* [2023\_12 EDI style guide V1.0](https://docs.google.com/document/d/1q3v-B55Ox9odCYveQyisxF5MgTaV2cJ4fNKLb8BT3dE/edit#heading=h.gjdgxs) (created end 2023\)  
* [Tone of voice guidelines](https://docs.google.com/presentation/d/1rdzB-4LpChd0BdU1Wd9AZdg2FJKckNFM13_mAJ6_DPc/edit#slide=id.g2ba747df42a_0_80) (created Jan 2024\)  
* [RPF Visual Identity Guidelines](https://drive.google.com/file/d/1PCewSY_DyFRmKsWfmxS40XQ606P9FdOG/view?usp=drive_link) can be found in the [Branding](https://drive.google.com/drive/folders/1bq8n0atqVlXr7Pr3LafQIXZTRa5mVVZY) folder (I suspect these guidelines will be updated soon; last updated 2020\)  
* [Code Club branding guidelines](https://drive.google.com/file/d/1GLO3Cu56I32psZ-0CnS3SDZeL2ee9kls/view) (created Sep 2024\)  
* [AI Learning Design Guidance](https://docs.google.com/document/d/1DUVO73q0Zeh_Mv_TMI_jvtBzwJ8QIq6JT9HWIsBgS54/edit?tab=t.0) (updated Nov 2025\)  
* [Generative AI: Principles](https://docs.google.com/document/d/1pAyg1mcfM49k60OamReofKhLm4BhDN9CKcaNIwLqRcg/edit?tab=t.0)

Accessibility resources

* [Alt text – why and how](https://docs.google.com/document/d/19tQltsQU9OwEWPrkCGm_ihwLQVd3t-9McNRWr9CTtX0/edit) (last updated Dec 2023\)  
* [Closed captions](https://docs.google.com/document/d/1vbBZ8ZJQxBUKrOt1fLK7NTTwsY8jzDzgEoyszHvJQJY/edit?tab=t.0) (February 2025\)  
* [RPF ‘How to Accessible’ for the web](https://docs.google.com/document/d/1o1sfFSsyvotoLv6KrDAbq_iKxWp1axHXsGq0rewhhnU/edit#heading=h.9z6zd53teez6) (last updated July 2022\)  
* [Accessibility in our comms slides](https://docs.google.com/presentation/d/1jxU8q4IJsWG8WzBqrTzfNU6ZTHr0EXn1QApzlWdXeHA/edit?ts=5ee0d959#slide=id.g59733b0869_0_11) (best practice for links, images, and structure and presentation; last updated June 2019\)

Product-specific stuff

* [Avoiding anthropomorphism in AI content](https://docs.google.com/document/u/0/d/1KSJKrEtkWYZ4WnKYw_bsu1lEojEzluXPBzpzYT4GpB0/edit) (created Dec 2023\)  
* Ada: [Isaac number formatting examples](https://docs.google.com/document/d/1x8xImB2HBCL2VCMZq6xHev57DJqtEcK-aKe9vGa8Mv4/edit) (last updated )  
* [Astro Pi Comms cheat sheet 2025-26](https://docs.google.com/document/d/1FdPc_C4kq1YqbVZALOinbOZuElwzB6whDCmgh31fFCs/edit?usp=sharing)(last updated )  
* Code club events: [Code Club Central Workshops](https://docs.google.com/document/d/1U3M-AJQPkRXVjRvFKjzosP4fbLvQVG-aEjLmGBTK_EI/edit) (last updated )  
* TCC: [Annotated example of an NCCE lesson plan and slides](https://docs.google.com/presentation/d/1mnRqnpfk8hurgIomS3eftuBLxxGJNC1A1Km3Jj-yb5I/edit#slide=id.p) (last updated )  
* TCC: [RPF TCC Resource naming conventions](https://docs.google.com/spreadsheets/d/12woCwqBnNo8kHWajSKhhkuOVp_hcsPP81EcP4ViVOOM/edit#gid=0) (from the learning team)  
* [A list of all Quick Reads](https://docs.google.com/spreadsheets/d/1rvvgxERRVVfUj-Gn9Grfnor1ocwZmseg1pTY_-Zq7Pg/edit?gid=0#gid=0), sortable by name or number, with links (created Nov 2025\)

Resources relating to editing and writing

* [Writing workshop – 3h – for print](https://docs.google.com/presentation/d/1ASBPiZzSXa1gu03Rd4J9zq--mZ7ktXqnfV-I7iXX0-E/edit#slide=id.p) (last updated )  
* [Beginner’s guide to reference styles](https://docs.google.com/document/d/1uwZSx3NJIBVkILw58dC0OvDphnpOjuf9jV3dwM3racw/edit) (last updated )  
* [Writing for localisation: top tips](https://docs.google.com/document/d/1Y-PoLvehJmNT8FifVG1nHs7AWBqJKdOlhY04h-oTlrE/edit) (reviewed April 2026\)  
* [How to deep edit](https://docs.google.com/document/d/1PffeeyMC9u59LwjzHOmwJozL0Yf8HF2guX56N5ws7Ec/edit) (notes on the LinkedIn learning course [Editing Mastery: How to Edit Writing to Perfection](https://www.linkedin.com/learning/editing-mastery-how-to-edit-writing-to-perfection?u=105851538)) (created Dec 2022, no updates needed)  
* [Copywriting for fundraising/support](https://docs.google.com/document/d/15Fax9JPRQAW2M7tXCffvVpof27sr68WK54qHUH_nK2k/edit) (based on an IDM course, no updates needed)  
* Notes on [editing for plain English](https://docs.google.com/document/d/1AvlLq0vVKe_2DNOB4lxVscXAE3-tR2zy2tsTjAC--F8/edit) (by Gemma, no idea of her source/s or when it was written, but the info is good) 

# 

# Intro {#intro}

Welcome to the Raspberry Pi Foundation’s Style Guide\! 

This style guide applies to the Foundation’s work, including general Foundation comms such as blog posts and emails, TCC content, Ada Computer Science, and informal learning content such as Scratch projects. We’ve simplified the style guide as much as possible so it applies equally to all of these content types, but there are still a few exceptions and content-specific info — this will be flagged in bold. 

This document is based on the original Style Guide from days of yore. It is a work in progress. It was updated following the split of the Trading and Foundation’s websites and communication channels ([Version 3.0](https://docs.google.com/document/d/10elWgjffo5c1KfoJaGHqB6xBkcoHQpclRvxBuY_3610/edit?pli=1#heading=h.l1yloli18x5d)). 

Version 3.1 has been rearranged so the things that the copy editors use most are at the top. General information is now towards the end. Please see the table of contents or the links in the document outline on the left for quick access to the desired section. Specifically, we use the product-specific stuff most, then the word list, then everything for reference. 

# 

# Section 1 – Product-specific guidance {#section-1-–-product-specific-guidance}

## Ada Computer Science \- Sarah {#ada-computer-science---sarah}

Product strategy with agreed vision, elevator pitch, and target audience (the copy in this does not have to be used verbatim, but what we say about the product should align with it):   
[Ada CS - Product Strategy](https://docs.google.com/document/d/1HyQqK1SpcowzpQIdsEWlA-gIYNeAkeYlPOhEiCGeTzc/edit?usp=drive_link)

[**Ada Computer Science Handbook**](https://docs.google.com/document/d/1c4AQVRAG2jhJu99I2SoX6DRsmLiaWx5pf_PGU_a6zzg/edit?tab=t.0)

[**Putting things in pink (or not)**](https://docs.google.com/document/d/1Exrk8UsX4rMxzXnnx7yW0lelZ62lngKb8Ehtwoa5ctg/edit?tab=t.0)

**Product name**: Ada Computer Science or Ada CS  
We have an informal agreement with Ada College not to refer to Ada CS as just “Ada”.

**Preferred terms:**  
\*\*Denary or base-10\*\* (cf. Decimal, which can be confused with fractional numbers instead of integer base-10 numbers.)  
\*\*Binary point\*\* – Binary point is the term for base-2 numbers, whereas decimal point is used for base-10 numbers or radix-point

\*\*Evaluate:\*\*

1. Use “evaluate to” when discussing the result of an expression/calculation, e.g. “The expression evaluates to \`True\`”, “The expression 1+2 evaluates to 3”, “This would evaluate to \$+102\$: \$64 \+ 32 \+ 4 \+ 2 \= \+102\$”  
2. Use “are evaluated as” when discussing how an expression/calculation is evaluated, e.g. “This would be evaluated as \$64 \+ 32 \+ 4 \+ 2 \= \+102\$”, “Following the order of precedence, this expression will be evaluated as \`(x \> 3 AND y \< 10\) OR z \== 0\`.”

Examples of both: 

* “The expression is evaluated. It evaluates to \`True\`.” (not “The expression evaluates. It evaluates to \`True\`.” or “The expression is evaluated. It is evaluated to \`True\`.”)  
* “The parts of the expression are evaluated in the correct order, and the expression evaluates to \`True\`.” (not “The parts of the expression evaluate in the correct order, and the expression evaluates to \`True\`.”)

**Number formatting**  
The Isaac platform uses LaTeX formatting to distinguish ‘mathematical’ numbers from ‘regular’ numbers. This means:

* They need to have a \$ symbol either side of the number.  
* All equations, expressions, and numbers that are part of an equation or expression should be in LaTeX, e.g. “\$2^5\$ means 2 to the power of 5, which is the same as \$2 × 2 × 2 × 2 × 2\$, which is 32.”  
* For clarity, equations or expressions should be entirely in LaTeX, including operator symbols and equals signs. E.g. \$2 × 2 × 2 × 2 × 2\$ not \$2\$ × \$2\$ × \$2\$ × \$2\$ × \$2\$.  
* Binary numbers, number bases, powers, and numbers with positive/negative signs should be in LaTeX.  
* Any numbers with symbols for units should be in LaTeX as the units will be rendered better on the screen. This includes %, ℃, °, Ω, for example, but not V, bit, byte, MB, etc. On the off-chance they should turn up, units with powers should also be in LaTeX along with their numbers. For example, m s–1, A m–2, cd m–2, mol m–3.

All other numbers do not require LaTex [For more examples, please see this doc](https://docs.google.com/document/d/1x8xImB2HBCL2VCMZq6xHev57DJqtEcK-aKe9vGa8Mv4/edit).

**Letters as numbers**  
Any letters in \$\$ will be formatted as italic, so this may be found occasionally when discussing variables, usually represented with n or x and y.

An exception is when writing time complexity in Big O notation, where the O has a ‘mathcal’ tag, which displays it with a calligraphic font. This makes it recognisable as complexity notation and not a function O taking an argument n (for example). Example: \$\\mathcal{O}(n^2)\$

**Note on LaTeX formatting:** If you need to keep text in LaTeX with text that is not in LaTeX and avoid a line break between them, e.g. in “\$0\$s”, use the following tags (shown here with example text): \<span class="text-nowrap"\>\$0\$s.\</span\>. Do not use these tags for long pieces of text.

**Useful HTML, if needed:**

* Angle brackets:   
  * \$lt; is a less than symbol (\<)  
  * \$gt; is a greater than symbol (\>)  
  * Example: “Proper heading structures (e.g. \&lt;h1\&gt; to \&lt;h6\&gt; tags)” displays as “Proper heading structures (e.g. \<h1\> to \<h6\> tags)”

**Regex formatting**  
Regex is used to match patterns rather than having to write loads of different variations.   
E.g. the answer num\_plays\\s\*(-\|—)\\s\*1 will match if a user enters "num\_plays", followed by 0 or more spaces "\\s\*", then either symbol for minus "(-\|—)", 0 or more spaces, and then a "1". 

You can use it for capturing spaces between the binary values, as well as an optional binary point ".?" after the first 0\. The start "^" means no more characters before it and the end "\$" means no more characters after.  
**Regex symbols and what they do:**

* \\s\* – any number of spaces (including 0\)  
* (-\|—) – either symbol  
* .? – optional dot  
* ^ – no characters before  
* \$ – no characters after

## Applied Certificate (updated Sept 2025\) {#applied-certificate-(updated-sept-2025)}

Background info:

Official name of the applied certificate: Raspberry Pi Foundation Certificate in Applied Computing

Official names of the Stage 1 modules:  
Introduction: Building skills for a digital world  
Module 1: Visual communication – Working with text and images  
Module 2: Data essentials – The power of spreadsheets  
Module 3: Digital wellbeing – Safety, responsibility, and security  
Module 4: Digital storytelling – Audio and video production  
Module 5: ~~Artificial intelligence and machine learning \- Grasping the fundamentals~~ Using artificial intelligence – Grasping the fundamentals  
Module 6: Connecting to the world – Build your own website

Stage 2 modules:  
Module 1: Data science – Build your own data investigation  
Module 2: Digital media – Shape your campaign  
Module 3: Programming – Develop your own adventure game  
Module 4: Web development – Using HTML and CSS  
Module 5: Cybersecurity – Design a safe digital product

Language around the certificate:

* Schools **register for** the Certificate in Applied Computing (or teachers register their schools for the Certificate in Applied Computing)  
* Students **enrol in** the Certificate in Applied Computing  
* Avoid “participate” as it does not capture the level of commitment required

Applied certificate modules mostly follow house style. They normally require a SPAG+house style check, and most text edits tend to be for plain English, AI, or EDI reasons. 

Deviations from house style (or things I always need to double check):

* Colons after bold text in bold (i.e. **Task:** Now do this). Colons after non-bold text not in bold, obvs. 

## Astro Pi (updated Dec 2025\) {#astro-pi-(updated-dec-2025)}

Product strategy with agreed vision, elevator pitch, and target audience (the copy in this does not have to be used verbatim, but what we say about the product should align with it):   
[Astro Pi - Product Strategy](https://docs.google.com/document/d/1OX7OUx6rl0l4UnlB7uyOpiiIyNMHr6xeVHsG4iw78JI/edit?usp=drive_link)

#### Astro Pi 2026/27

A few key things (incl key dates) on this year's round from Fergus [Astro Pi 2026-27](https://docs.google.com/presentation/d/1Cadz1X_xIKxmVClyS1dmOWVv4b_0P5fJMHUkRPZwGJQ/edit?slide=id.g2b6e92f3986_0_0#slide=id.g2b6e92f3986_0_0)

#### General:

Programme title: (The) European Astro Pi Challenge

The years should be styled as ‘2025/26’, not 2025–26. 

Astro Pi should be referred to **as a challenge, not a competition**.

The **missions should not be referred to as challenges**, as this blurs the lines between the individual missions and the Astro Pi challenge. You could use ‘missions’, ‘activities’, or ‘tasks’ depending on the context.

When referring to the computer programs students and young people write for their experiments, **only the noun ‘programs’ should be used and not ‘code’ or ‘codes’**, as ESA were using these words incorrectly.  
   
**The verb ‘to code’ should be used to describe the action of writing a computer program.** However, never write things like “Students and young people code computer programs.” 

The use of ‘code’ as a noun in formal materials (e.g. the creator and mentor guides) should be avoided. It can be used judiciously as a noun in informal materials (e.g. marketing copy and design assets) instead of ‘program’ when there is a particular wish to engage young people (with the idea being that writing code is less daunting than writing a program). Please still note that the nouns ‘program’ and ‘code’ are not absolutely interchangeable — if one is swapped for the other, the meaning of the text will change. Also be aware of setting an example to ESA that code as a noun is okay, which is something we want to avoid. Look out for this especially in ESA versions of text.

‘Coding’ as a noun is OK in all circumstances.

Creator guide, mentor guide, rulebook, etc. all lower case.

Use ‘mentors’ rather than ‘educators’. 

Astro Pi Replay — the software tool for simulating how MSL programs run on the Astro Pis aboard the ISS. Astro Pi Replay is now downloadable as a web app and can be toggled to run in the browser offline. Note the upper-case R. There’s two versions of the tool — an online version and a plug-in for Thonny.  So you will see Astro Pi Replay referred to as “the Astro Pi Replay tool” (online version) and “the Astro Pi Replay plug-in” (Thonny version). Plug-in is never correct for the online version. You may be able to get away with calling the Thonny version “the Astro Pi Replay tool”, but try to avoid it. Both versions together can be referred to as “the Astro Pi Replay tool”. 

Blog posts often require an RPF and ESA version. Make sure to remove references to ‘us’/’we’. and adjust the tone of voice to be more bland for the ESA version.

## UK Bebras Challenge {#uk-bebras-challenge}

#### About the programme we run

RPF organises the UK Bebras Challenge. E.g. 'The UK Bebras Challenge is organised by the Raspberry Pi Foundation.'

The international body does not provide style guidelines, so we are making our own rules.

Name

* Always use 'the UK Bebras Challenge' in run-on text. Only use 'UK Bebras Challenge' if space is very tight, e.g. in short titles/headings/small design assets such as social cards/banners. Unless it's a modifier. E.g. 'There have been hundreds of thousands of UK Bebras Challenge participants over the years.'  
* 'UK Bebras' for short in paragraph text if the full name has been used already.  
* Never 'the Challenge' for short.  
* Never 'Bebras UK'.  
* Never 'the UK Bebras Computational Thinking Challenge'  
* Bebras as a standalone term for the challenge is only OK in quotes from participants, not in wording from RPF.  
* Don't capitalise 'challenge' when you're using the word with an indefinite article. E.g. 'The UK Bebras Challenge is a free-to-enter annual challenge.'

Misc

* 'Bebras task' is OK (even for UK-specific tasks).  
* the Bebras International Task Workshop. RPF organised the 2026 iteration.

#### About the international initiative/challenge

* "Bebras is an international initiative aiming to promote Informatics (Computer Science, or Computing) and computational thinking among school students at all ages." (From [https\://www\.bebras.org/](https://www.bebras.org/) 07/05/26)  
* the Bebras Computational Thinking Challenge. E.g.:  
  * 'The UK Bebras Challenge is the UK version of the Bebras Computational Thinking Challenge.'  
  * 'More than 3 million students from 59 countries took part in the Bebras Computational Thinking Challenge in 2022.'  
* The 'Bebras International Challenge on Informatics and Computational Thinking' is the title in the header of the [https\://www\.bebras.org/](https://www.bebras.org/) website, however, this doesn't seem to be widely used.

## Code Club (updated Sept 2025\) {#code-club-(updated-sept-2025)}

Product strategy with agreed vision, elevator pitch, and target audience (the copy in this does not have to be used verbatim, but what we say about the product should align with it):   
[Code Club - Product Strategy](https://docs.google.com/document/d/10W1RIdOLpST3LCqLGN_tH72Zp7hxH50mTJo-G4-9jxk/edit?usp=drive_link)

**Clubs brand refresh (Project Demeter)**  
This is a glossary of terms that have been agreed or have come up in assets and web copy for the 2024 Code Club brand refresh, as well as some terms that should be avoided. We will add to this as we go along.

The key document to refer to is [Project Demeter - canonical](https://docs.google.com/document/d/1PoQ0H3bx38SL8DXxDcbN5MUg1N7tDGqzrp3wkAnuVsA/edit?usp=sharing).  
You can also find the [updated brand guidelines for Code Club here](https://drive.google.com/drive/folders/1EPAvE1n5ZRwJnj1pxeh5CH5b1fveGels).

**Referencing the Foundation**  
We say "Code Club is part of the Raspberry Pi Foundation".

Design assets/resources should have the following line for our charity status:

“Code Club is part of the Raspberry Pi Foundation, UK registered charity 1129409.” not the version that includes the US charity status too. Include the full stop at the end. 

**Glossary of Code Club terms**  
This glossary doubles as a resource for copy editing and translation.

| Term | Description |
| :---- | :---- |
| Creators (Default option \- use if possible) | The young people who attend Code Clubs (preferred term). The term can be qualified if the audience may not be familiar with it, for example ‘tech creators’, ‘young creators’, ‘digital creators’, ‘digital tech creators’ (don’t overuse as it’s a little wordy). ‘Creators’ should **not** be treated as a proper noun, so should be capitalised as usual (i.e. only at the beginning of a sentence or if it is part of a title written in title case). |
| Club members | The young people who attend Code Clubs (alternative term to the default option of ‘creators’, which should be used if possible).  |
| Learners | The young people who attend Code Clubs (alternative term to the default option of ‘creators’, which should be used if possible). Avoid the terms ‘students’, ’pupils’, etc. |
| Young people | Broadly, people under the age of 18\*; however, the understanding of this term will depend on the audience and market, so consider the context before using it.  The term ‘young people’ will most likely be used where the audience may be unfamiliar with Code Club and the term ‘creators’. 'Youth' may be used as an alternative to avoid repetition or where it is more suitable for the context. Generally, avoid the term ‘children’, as this term is less likely to resonate with teenagers, for example. However, ‘children’ can be used if it makes sense in the context (e.g. referring to primary school–aged children in the UK). \*In the 2030 Strategy document, we specify “Our beneficiaries are young people aged 5 to 25 years old. The majority of our work focuses on school-aged young people (which generally means 5 to 18 years old).” The recommended age range for Code Club is 9–16, but all school-aged people are welcome depending on their ability to access our materials. In India, “young people” generally refers to 15–29 year olds.  |
| School-aged children, school-aged young people | Young people who are of an age to attend school (this may have different meanings in different countries and education systems).  Code Club is open to all school-aged children and individual clubs set an age range that is appropriate for their context. Consider the context when deciding whether to use ‘school-aged children’ or ‘school-aged young people’. |
| Code Club | Can be used to refer to: An individual club, for example: "Run a Code Club", "Download resources for your Code Club" The community/movement/network of clubs (see below) |
| community, movement, network | The terms ‘community’, ‘movement’, and ‘network’ can all be used when referring to Code Clubs. The preferred term will depend on the context. **Community**: Could refer to all Code Clubs, or all adults and young people involved in Code Club (this can include parents, for example). It is the broadest term, and the most accessible term for readers who speak English as an additional language. It is a more people-focused term.  We try to avoid phrasing things in such a way as to imply the community belongs to us. As such, be careful with the use of “our community” vs “the community”. If in doubt, avoid saying ‘our community’; say ‘the community’ instead.  “Our community” can, however, be used to include us as part of the community, (i.e to show that we (Code Club team) are part of a shared community with the audience, e.g. mentors).  Do not use “the Raspberry Pi Foundation community” for example, although “the Code Club community” is okay.    Examples of use include: “Code Club is a global community of coding clubs where young people develop the skills and confidence to become digital tech creators.” “Meet the community” “Join the Code Club community” **Movement**: Could refer to all Code Clubs, or adults involved in running Code Clubs. For individuals, it implies active involvement in Code Club and its growth and success. It will likely be used less often than ‘community’ and ‘network’. Examples of use include: “Code Club is a global movement of free coding clubs for school-aged young people.” “This Charter sets out the principles that are shared by all Code Clubs, and all club leaders and mentors commit to this Charter as part of joining the movement.” **Network**: Refers to all Code Clubs. It is a more entity-focused term and would not be used to refer to individuals. Examples of use include: “Code Club is a global network of free coding clubs where young people learn how to create with technology.” |
| Mentors | All adults who support young people at a club. Club leaders are mentors. Can also include under-18s who are club members but primarily support other club members during sessions (i.e. youth mentors, see below).  |
| Club leaders | Adults with responsibility for organising (starting/running) their own club. All club leaders are mentors (not all mentors are club leaders).  |
| Youth mentors | Experienced creators can grow and develop further as youth mentors, supporting other creators in their Code Club. |
| Volunteer (noun/verb) | People who give their time for free/The act of someone giving their time for free. Avoid ‘volunteer/volunteering’ in contexts where it could include educators, who may not be volunteering their time (all volunteers are mentors, but not all mentors are volunteers). Acceptable contexts for ‘volunteer/volunteering’ include when referring to joining an existing club as a volunteer. |
| Growth Partners | Growth Partners work with their local community or region, starting with a minimum of five clubs and usually growing to up to 100 clubs. All partners start as Growth Partners. |
| National Partners | National Partners support all clubs and mentors in their country. They have the capacity and ambition to work and grow the network of clubs nationwide. |
| Strategic Partners | Strategic Partners are organisations that are thought leaders in tech or computing education in their country. They have all the responsibilities of a National Partner, and they have the scope and ambition to collaborate on innovative projects with national significance. |
| Global Partners  | Organisations that support the growth and operation of Code Clubs internationally. They may sometimes be referred to as ‘Global Clubs Partners’ if in a context where they need to be distinguished from other types of partners, e.g. Experience AI partners. ‘Global Partners’ is capitalised, but ‘global partnerships’ is not. Essentially the umbrella term for the above partner types.  |
| Codealong | An activity where young people (or mentors) follow an instructor in real time as they complete a coding project. It can be live or recorded. For example, in a ‘Space talk’ codealong, an instructor such as a club leader would complete the steps of the ‘Space talk’ project while the club members follow along, completing the steps alongside the instructor. |
| Project path  | A collection of projects that cover a set of skills needed for a particular piece of hardware or software alongside design and engineering skills. As a result of working through a path, creators are empowered to build their own ideas and create solutions to situations they or their communities face, with increased independence. |
| Experience levels | We talk about young people’s “experience levels” rather than “abilities”, “skills”, or “skill levels” (or similar), as it is more inclusive. For example, “Code Club is open to young people of all experience levels”. |
| Life skills | Skills beyond technical skills, such as problem-solving, communication, and teamwork. Avoid ‘transferable skills’ (unless ‘life skills’ has been used too frequently in the same piece and an alternative is needed) and ‘soft skills’. |
| Code Club leader guide | A resource to help club leaders run their club (can be found on the Code Club website). No capitals for leader guide. |
| Code Club Charter | An agreement that sets out club leaders' and mentors’ commitments, and the Raspberry Pi Foundation’s commitments to club leaders and mentors. ‘Charter’ should be capitalised. |
| Code Club Conference | Conference for club mentors, run annually since 2023\. Previously called the Clubs Conference. |

**Terms to avoid or consider carefully before using**

| Extracurricular, after-school | Avoid “extracurricular” as it is not a very accessible term for readers who speak English as an additional language. Avoid "after-school" because it is too prescriptive about timings. If you need to refer to this aspect of Code Clubs, consider whether “outside of lessons” might be suitable (see below). |
| :---- | :---- |
| Outside of lessons | There might be instances where it makes sense to say that Code Clubs run outside of lessons, e.g. in a flyer for schools. However, we generally avoid describing clubs like this because clubs run in lots of different types of venues. |
| Volunteer-led | Note from Tamasin: We might look at toning down the amount of "volunteer-led" as it can be seen as excluding educators. But it is so important for some community clubs that I don't think that it is essential that we avoid it entirely. |
| Facial recognition (for US Code Clubs) | Use ‘facial detection’ in a US context instead. An explanation about data being processed locally should also be included.From Connor C:“My read is that this is less about the project \[Chomp the Cheese\] and more about the current climate in the US. The Flock camera backlash has made a lot of people deeply wary of anything in the surveillance space. Once a school hears the phrase it feels like the technical distinction stops mattering and they are hard to reason with.” |

**CoderDojo**  
CoderDojo was a historically separate coding club network that RPF supported, which was then merged into the Code Club brand in 2024\.

RPF communications now only refer to Code Club and our support for the CC network and people involved in CC sessions. Community members may continue using ‘CoderDojo’ to refer to their club or local network (e.g. CoderDojo Nederlands is our Dutch partner) and are able to use our support resources and platforms.

In our comms, if we use quotes/statements from people who call their club a CoderDojo/Dojo, we amend the word from, e.g., ”I attend a Dojo” to ”I attend a Code Club” when the quote isn't attributed to an identifiable person. Alternatively, we use "I attend a \[club\]" if it's possible to do this without creating awkwardness or confusion.

**Code club event/workshop title format**  
Topic workshop no.: Hook  
Examples:  
HTML & CSS workshop 1: Introducing the pedagogy, resources, and fun  
Micro:bit workshop 1: Introducing the pedagogy, resources, and fun   
Micro:bit workshop 2: Supporting coding with confidence

I made the Clubs team a [mini style guide for comms about workshops](https://docs.google.com/document/d/1U3M-AJQPkRXVjRvFKjzosP4fbLvQVG-aEjLmGBTK_EI/edit). It has the key points for formatting time and date, titles, and a couple of pointers for descriptive text. It’s mostly the same as what’s in here, it’s just everything they may need in one place, so it may be useful as a quick cheat sheet for us too.

## Code Club Projects site \- Abi {#code-club-projects-site---abi}

Product strategy with agreed vision, elevator pitch, and target audience (the copy in this does not have to be used verbatim, but what we say about the product should align with it): [Code Club Projects - Product Strategy](https://docs.google.com/document/d/1qLUWaZ_uYCsRowiPcZzm-Bxkz-3j7cFUkNGnPhd8aM4/edit?usp=drive_link)

Our repository of non-formal learning content, formerly the projects site/Projects site, was lightly rebranded as Code Club Projects in 2024\.

As CCP projects are generally edited in GitHub, here’s some general guidance for how to format headings etc in Markdown: [Markdown Cheatsheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet) 

| Important\!  You can’t use colons in collapse title headings — it breaks the build\! Collapse titles look like this, i.e., there’s already a colon\!  ![][image1] |
| :---- |

\*\*When working in GitHub, Copy Editors have free reign over the draft branch.\*\*   
Almost all CE suggestions the Copy Editors make are things that anyone in the ILT would be quite happy to accept. The only suggestions that some in the ILT might have a problem with are where there are major structural changes to a project.  
   
The ILT will only pull the changes into the master branch that they agree with, so they really don’t need separate docs/emails/slack messages. They can see each change that is made and accept or decline it.

**Scratch projects** have their own style.   
[This document contains the most up-to-date advice and examples](https://docs.google.com/document/u/0/d/17DhJSaT6Fqo4NDo7hVxzIeiZwrZpOP1eIgxoQhEO1NI/edit); however, I find the [Style Guide for Learning Resources](https://github.com/raspberrypilearning/style-guide/blob/master/style-guide-for-resources.md) easier to follow and more useful for a quick reminder. The tl;dr version of those docs is:

* Things to click in bold  
* Things to type in backticks  
* Names of parts of code and code in backticks  
* Bold for emphasis and new concepts

The final section in a resource should be titled What next?, not What's next?

In ingredients, the ingredient page should not include a title (e.g. \#\# Create a Scratch account) — the title should be in the meta. In the meta, the title under “steps” should be the title of the ingredient, not “Introduction” (e.g. title: Create a Scratch account).

In Code Editor projects, leave “\#\#\# Now run your code” as it is when it appears, because if it’s changed, the play symbol that appears next to it will no longer appear.

**Preferred terms:**  
For jumper wires, the terms ‘pin–pin’, ‘pin–socket’, and ‘socket–socket’ should be used, rather than ‘male-male’/‘M-M’, ‘male-female’/‘M-F’, and ‘female-female’/‘F-F’, as ‘pin’ and ‘socket’ are more inclusive terms. 

**Cables versus wires**  
Wire is the preferred term.   
Wires are single conductors unless we attach them to each other.  
Cables are wires covered in insulation and wires only become a cable when a group of wires are joined together. So wire is the preferred term.  
Although people generally assume that all jumper wires/cables are cables, we should really be using wire in almost all circumstances.

### Lego

We have LEGO-sponsored content on the projects site.

There wasn’t that much that was unusual about the LEGO pathways. Again, the basics apply:

* Things to click in bold  
* Things to type in backticks  
* Names of parts of code and code in backticks  
* Bold for emphasis and new concepts

But there are a few things to note regarding the Lego terminology:

* Lego – the Lego Group has trademarked LEGO (all caps) and LEGO should be used to refer to specific LEGO products, which is basically all of them in Build HAT projects.   
* LEGO love their trademarks\! Add a ® after LEGO and a ™ after the product name (see below for examples). It can look horrible with all these symbols, so I try to use the full name of the products sparingly. E.g. “Add the motor controller” rather than “Add the LEGO® SPIKE™ Prime motor controller”. However, the full name and trademark symbols should appear at least once on every page where the Lego products are being explicitly discussed, and ideally once in every subsection for longer pages.    
* In non-Build HAT projects, where Lego is being used as an example building material, such as “You could build something out of Lego bricks, an egg box, a milk carton, or anything else you have to hand”, then Lego is an acceptable usage (only L capitalised and no need for trademarks). However, always put a noun after 'Lego' when talking about the material, e.g. Lego bricks, Lego components, etc.  
* Plural Lego bricks etc., never Legos.  
* Build HAT (with space) refers to the physical hardware; BuildHAT (no space) refers to the library and other coding elements.  
* Lego sets that work with the Build HAT: LEGO® Technic™; LEGO® Education SPIKE™; SPIKE™ Prime (terminology provided by Lego)  
* The piece of Lego designed specifically to work with/house the Build HAT is called the maker plate. The standard plate is called the build plate. The large flat pieces that you build your cityscape on are called base plates.

### Unity

We have Unity-sponsored content on the projects site.

There have only been two Unity pathways at this point, so we haven’t encountered everything it’s going to throw at us. Sticking to the basic theme behind the Scratch project formatting, here are rules to follow for Unity pathways:

* If you want to look up anything that is unfamiliar, to see if it has an article before it or if it should be capitalised or not, you can search [https\://docs.unity3d.com/](https://docs.unity3d.com/)  
* Sentence case headings and subheadings  
* Bold for emphasis  
* GameObject, Inspector window, Physic Material (Physic instead of Physics when it appears as ‘Physic Material’. ‘Physics’ when talking about the science principle), Project window, Shift (shift key), Transform position, Unity Editor, and Unity Hub \- note capitals  
* Bold for instructions of where to click, button names, things to drag, etc. But: Non-specific models, GameObjects, etc. not in bold even if being selected, dragged or clicked, e.g. Click on the ‘Raccoon’ GameObject, then add Box Collider. Drag your chosen GameObject to the Scene view, and add a Box Collider to it.  
* \<kbd\>text\</kbd\> for names of keys  
* Backticks for anything the user has to type  
* Backticks for code, names of methods and variables, file names. Note: For file or script names, we used backticks the first time the file is mentioned, since this is the first time it’s named/the user is asked to enter the name. After that, we use bold for the name of the file or script.  
* Player with a capital if referring to the character on screen; lower case player for person playing the game  
* ‘Scene’ and ‘script’ lower case, except ‘Scene view’ i.e. ‘Play your scene’ or ‘Save your script’ but ‘Go to the Scene view’  
* Names of folders, properties, components, windows, settings all normal text with a capital letter (no bold, no quotes, no backticks) i.e. the Hierarchy window, the Transform component, etc.; the methods, windows, components, etc. part of the name takes a lower case m, w, c, etc.

## Code Editor \- Sarah {#code-editor---sarah}

Product strategy with agreed vision, elevator pitch, and target audience (the copy in this does not have to be used verbatim, but what we say about the product should align with it): [Code Editor - Product Strategy](https://docs.google.com/document/d/1WyZFoojTOjy8UXJEBKknCWu58RleXzq8t-OTVD1-Xv4/edit?usp=drive_link)

* The full name is "Code Editor"  
* Use any lower-case article appropriate  
* Can be abbreviated to Editor after the first use of the full name  
* Depending on the context (for example, in Code Club comms), it might be referred to as “the Raspberry Pi Foundation’s Code Editor”

**Programming languages/functionalities**  
Do **not** overuse the following — we want to avoid creating the impression they are distinct products as opposed to features of the Code Editor:

* Blocks editor (see for reference [2603 Blocks editor: Key messages ](https://docs.google.com/document/d/1Ysc_uuXkieBT9S21jMSoDbGnb6NBIEkRexmNOklXjjM/edit?tab=t.l8jy71mexhbr))  
* Python editor  
* Web editor (not 'HTML editor' or similar)  
* The names should be used with a definite article, unless in a title

**Code Classroom (FKA Code Editor for Education)**

The official name is Code Classroom (Rebrand on 7 May 2026; the name used to be Code Editor for Education. Internally, the abbreviation used to be CEFE or CEfE — avoid using these externally. The terms and conditions used the abbreviation to avoid constant repetition, but that’s one of the few exceptions.)

The original product interface and Q\&As were copy edited, however, features are being added and specific wording and word usage may have changed. So if you see something online or on Code Classroom that contradicts the advice here, let me (Sarah) know and I’ll see what can be done.     

* Some basics:  
  * There are different levels of users, including owners (the school employee who registered the school’s account), teachers, and students  
  * Students can be grouped into classes  
  * Students are also referred to as school or class members  
  * Teachers and owners are school members too (but not class members)  
  * Projects contain starter code created by the teacher and the student’s version of the code  
  * Projects can be shown to or hidden from a class/classes  
* Things to watch out for:  
  * Random capital letters, especially for “School account”. Correct wherever you see it.  
  * There was a version where buttons and text said “Create student” or “Create teacher”. Correct to “add teacher/student” or “create teacher/student account”.  
  * When discussing features in development, Mel doesn’t like “coming soon” as she feels it creates expectations around the word soon. She prefers “coming in the future”, which I hate, so we settled on “future features” and “upcoming” as alternatives.     
  * Avoid “school/class members” in comms unless describing that specific function. Use “student” and “teacher” instead. Use “owner” only where discussing the specific responsibilities of that role or how to set up a school account.

## Coolest Projects \- Sarah {#coolest-projects---sarah}

* The online showcase is just called ‘Coolest Projects’.  
* In-person events are called ‘Coolest Projects \[country name\]’, for example ‘Coolest Projects Malaysia’ or ‘Coolest Projects Ireland’.

The showcase and event names can’t ever tell the full story of what Coolest Projects is, so where appropriate, the name should be followed by a tagline or by narrative in the copy. These were the taglines we used in 2023 — **note the use of ‘showcase’ versus ‘event’**:

* For Coolest Projects: an annual online showcase for young digital tech creators around the world  
* For Coolest Projects Ireland: an in-person event for young digital tech creators in Northern Ireland and the Republic of Ireland

An example of a more narrative description to include in copy would be ‘Coolest Projects is an annual online showcase for young digital tech creators around the world. Coolest Projects celebrates and inspires kids who create with digital technology.’

From 2024 onwards \- the CP team would like to avoid “register”. They like ‘enter’ CP and ‘submit’ a project, but not ’register’.  
Likewise, avoid ‘registration’, replace with “entries open” or similar.

## The Computing Curriculum \- Tom (low priority) {#the-computing-curriculum---tom-(low-priority)}

### Kenya version

Links to 2026 templates and some other guidance from Kenya team [Kenya Resources CE Checklist](https://docs.google.com/document/d/1Zo1WCmGUfz5H2iYhDEWkXaxAMQhfrgWFgXuAnhZCgE4/edit?tab=t.0)  
Government guidance (but always check for the shared link and page in the unit ticket to know which part of the guidance to read)  
[ICT Grade 10 - July 2025.pdf](https://drive.google.com/file/d/1tT2NXWjmKRIUx4H4mX08-_IJGN5GZ3PT/view) Gov. curriculum design guidance for ICT-related units  
[Computer Studies Grade10 - July 2025.pdf](https://drive.google.com/file/d/1e5lBROYbbw6JeVCduFMCkWh1MbluV5M8/view) Gov. curriculum design guidance for comp studies-related units

Lesson plan formatting:  
Colon between lesson no. and title.   
Two forms of learning objectives \- awaiting clarification of preferred version  
Watch out for stray capital letters  
In the lesson plan each slide is introduced with “Display slide x:” followed by the action the teacher should take (sentence should start with a verb)  
All bullet points in RPF red (cd2355)  
Key vocab \- only first term capitalised, commas to separate, no full stop

**Preferred terms**

* **Learners** preferred to students (cf. South Africa preference)

**Describing gender:** Be extra careful with questions surrounding gender \- Leonida advises that we deviate from our EDI guidance, stating “the question “How do you describe yourself?” is sensitive in Kenya, particularly since the material will be shared with schools. It is a delicate area, especially if reviewed by the Ministry of Education. To avoid any potential concerns, we could simplify this section to state gender only, with the options “Male” and “Female” or to remove the broader self-description question altogether.” 

### South Africa curriculum content

**Official education terminology**  
Foundation Phase (FP) \= Grades 1–3  
Intermediate Phase (IP) \= Grades 4–6  
Senior Phase (SP) \= Grades 7–9  
CAPS \= Curriculum and Assessment Policy Statement

**Templates** once reviewed and marked as approved in linked folders:  
[Resource templates for Grade 1 and 2](https://drive.google.com/drive/folders/15WmBBWkg3q1eFNAvxa4Vo-mZspWz7e9r) (i.e. Foundation Phase (FP), in Eastern Cape region with EC Department of Education (ECDOE))  
[Resource templates for Grade 4](https://drive.google.com/drive/folders/1MycQs-BDdugzCxnznnYVxpKC2vZOMdBh?usp=drive_link) (i.e Intermediate Phase (IP), in Gauteng region)

**Preferred terms**: [South Africa ECDOE training materials: Terminology list](https://docs.google.com/document/d/1YkOjIDv9QBrPTwenvG7D95XFmUmxH4PiPDiTjTycaYI/edit?tab=t.0#heading=h.s5jyd1hcezn0) (02/09/26 Jacqui is updating this)

### **Legacy England (non-NCCE) version** (2023 onwards)

This material is no longer updated and is superseded by the content created for Oak National Curriculum

* The full name is “The Computing Curriculum”  
* It can be shortened to “the Curriculum” if necessary after the full name has been used  
* Don’t use an acronym in public-facing content  
* “the Raspberry Pi Foundation’s Computing Curriculum” is fine, if in a context where it makes sense to specify  
* NCCE stuff for reference  
* [Annotated example of an NCCE lesson plan and slides](https://docs.google.com/presentation/d/1mnRqnpfk8hurgIomS3eftuBLxxGJNC1A1Km3Jj-yb5I/edit#slide=id.p)  
* [TCC naming conventions](https://docs.google.com/spreadsheets/d/1mBrVx1orTuMMCFukO5kbhyD8TQeO6wc7_-eJTma2IpQ/edit#gid=0)  
* [Teach Computing Curriculum notes](https://docs.google.com/document/d/1Dpyza_Ohz9LS-NeTyz_P_clcBDVjyP5GPdHDcT-_8Mc/edit?pli=1#heading=h.i5ljagqu5rql)

**General formatting** (for consistency with old/NCCE content):

* **Font:**  
  * Teacher-facing TCC documents should be in Roboto. Code in Roboto Mono. **Note:** Scratch blocks should be in black and white. Handlee can be used to represent handwriting (e.g. in solutions sheets).   
* Text should be ranged left, ragged right, and never justified or centred. Use 11pt for standard body text and 16pt for headings.  
* Use bold type for emphasis where appropriate i.e. subheadings and to highlight sections within the body text.   
* Do not use italics, unless for foreign words e.g. coup d’etat.   
* Use single quotation marks when referring to the title of a document.  
* Software modules: Separate the names of the software and the module with a colon, e.g. J2Data: Pictograms  
* When functions are referred to in text, if they are different in different programming languages, use descriptions of the function in single quote marks instead of names — e.g. A 'write lines' function typically takes an array of strings and writes them to a text file.  
* Titles of courses, resources, blogs etc. take the following form: first word capitalised, then lower case. In body text, you can highlight a title with either a hyperlink or single quote marks e.g. The course ‘Bringing cutting edge science into the classroom’ is running this month.  
* TCC strand, unit, lesson, and activity names should be in sentence case with an initial capital letter. If they are referred to mid-sentence, use single quotation marks (e.g. “see the ‘Programming’ and ‘Creating media’ units”). If they are listed in bullet points like items or in table headings, etc., omit the single quotation marks.  
* Figure captions should briefly describe the figure and should end with a full-stop.  
* Key vocabulary should be formatted with each word or first word of each phrase taking a capital letter. For example:  
  Protocol, Internet protocol (IP), IP address, Hypertext transfer protocol (HTTP), Hypertext transfer protocol secure (HTTPS), World Wide Web (WWW), Domain name, Domain name system (DNS), Uniform resource locator (URL), Transmission control protocol (TCP)  
* No bullets for the assessment opportunities section

**Preferred terms:**

* “Last/Next lesson” is preferred, rather than “Last/Next week”  
* “Learners” is the preferred term, rather than students/pupils/children etc.  
* ‘Worksheet’ is preferred over ‘activity sheet’. A handout/resource and an activity sheet/worksheet are slightly different, however, as the learner does not do anything with a handout/resource other than read/refer to it.  
* Avoid use of “we” — if it is an instruction, use “you” (e.g. “Next, you will do this” rather than “Next, we will do this”). This is mostly for NCCE and TCC content, but can be applied across the board as good practice.   
* Likewise, addressing the teacher directly is preferred (e.g. “Now introduce the next activity.” instead of “Now the teacher introduces the next activity.”)  
* Use ‘them’ rather than repeating ‘the learners’ over and over. (“Tell the learners that there are lots of people who use desktop publishing in their jobs. Ask them if they can name some examples.”) Also, ‘students’ can be used sparingly to avoid excessive repetition.

**Things to look out for:**

* Check that there is no “Save a copy” hyperlink anywhere — the team is removing this when they update so that teachers come to the website to download the latest version  
* Check for ncce.io short links  
* If there are screenshots anywhere (especially in slides), check that they can’t be expanded to show the rest of the screen (sometimes, if an image is a screenshot that has been cropped, it will show the rest of the screenshot if you double-click on it)  
* Don’t update the date in “Last updated” (unless the TCC team say to). 

## Experience AI (updated Sept 2025\) {#experience-ai-(updated-sept-2025)}

[Experience AI Handbook](https://docs.google.com/document/d/1EMMel71jc6jAJqVhP0kVySsQqsYEOYhwc5aG3mZ8j_Y/edit?tab=t.0#heading=h.5p4zsf2tq7r)

The unit of work is called ‘Experience AI Lessons’ and the challenge is called ‘Experience AI Challenge’. If the full title is used, in any context, e.g. “when you use the Experience AI Lessons”, capitalise ‘Lessons’ and ‘Challenge’. Otherwise, use lower-case ‘lessons’ and ‘challenge’, e.g. “when you use the lessons”.

**Definitions:**   
The Research team is working on definitions with the team at DeepMind. [These slides](https://docs.google.com/presentation/d/1VSz94vK84HoxVE3V6efXmlr6ai2N9gRaydKLFUnl3XU/edit#slide=id.gddd4122191_1_6) provide information about the process, along with the working definitions as at the time of the workshop (November 2022\) and links to other working documents. The definitions are being finalised, so for now (18 January 2023), I am checking with the team that any definitions in lesson plans are the correct versions to include for now.

**Avoid anthropomorphism\!**

* Descriptions such as “like a brain” lead to misconceptions around autonomy and agency.  
* Avoid countable nouns for AI, use “AI system/application”, “machine learning model”, etc.  
* Avoid associating AI with a machine/embodiment, e.g. not a cute/smiling robot — AI applications are not necessarily ‘a machine’

[More notes on avoiding anthropomorphism](https://docs.google.com/document/d/1KSJKrEtkWYZ4WnKYw_bsu1lEojEzluXPBzpzYT4GpB0/edit)

**Preferred terms:**

* Data-driven  
* Rule-based  
* AI project lifecycle  
* Pre-labelled  
* Retrain (rather than ‘re-train’)  
* Confidence threshold  
* Refer to ‘students’ rather than ‘learners’; ‘creators’ in the challenge   
* User-focused (rather than ‘human-focused’)  
* Biased (not biassed)  
* Data set \- two words  
* Blueprint, Creator’s Guide, Mentor Guide \- note capitals  
* Staff at Google DeepMind, Google DeepMind staff members, etc, not Google DeepMinders

**Talking about Google**

* The Experience AI resources (with the exception of AI Quests) were co-developed by the Raspberry Pi Foundation and Google DeepMind.  
* Refrain from using ‘Google DeepMind’ and ‘Google’ interchangeably — the former is a specialised division within the latter. In most copy about Experience AI, we’ll be referring to Google DeepMind, not Google.  
* We may also sometimes refer to [Google.org](http://Google.org) (the philanthropic arm of Google), which serves as a funding source for some Experience AI partners. Refrain from using ‘[Google.org](http://Google.org)’ and ‘Google’ interchangeably. 

**Experience AI partner network**

* Experience AI community of practice (note lack of capitals).  
  * Always use 'Experience AI community of practice' in the first instance. Thereafter, shorten to 'community of practice' when necessary to avoid repetition.  
  * Ideally always spell out 'community of practice'. Abbreviating to 'Experience AI CoP' is only acceptable under space constraints. Avoid using 'CoP' by itself unless you are entirely certain readers will know what you're referring to.

**AI Quests**

* AI Quests was developed by Google Research in collaboration with the Stanford Accelerator for Learning. The Raspberry Pi Foundation was consulted during the development but is not officially a co-developer.  
* AI Quests is a browser-based learning experience that lets students step into the role of AI researchers. Through interactive, story-driven activities, they’ll explore essential AI topics such as data preparation, testing and evaluation, and bias in AI systems.  
* When referring to the product as a whole, treat ‘AI Quests’ as singular rather than plural, e.g. “AI Quests is a browser-based learning experience.”  
* When referring to specific quests, but not the product as a whole, don’t use capital letters, e.g. “a new quest about flood prevention” or “some exciting new quests for your learners to try”.  
* [This blog](https://docs.google.com/document/d/1UjaB28jovi9xEEfywx3Qdz_B2H-OCa5xm-y-dxM0BFY/edit?tab=t.0) provides a useful overview of AI Quests.

 

## Experience CS {#experience-cs}

Useful docs:  
[Model lesson plan based on CE feedback](https://docs.google.com/document/d/1tjcXV5BFJqJgnwacHp4tZGKxP-USBOzYOuvEUu1zHIg/edit?tab=t.0)  
[Model slide deck](https://docs.google.com/presentation/d/1bLFoQziax3JEh_5ZUDERcUc3d-ABSZJVRmYK5ATeL-4/edit?slide=id.g3678575b0ec_0_0#slide=id.g3678575b0ec_0_0)  
[Model unit overview](https://docs.google.com/document/d/1rnHJqMGY2vuRWa7SdoSJwHd38ybQFe0wAzUneOayZfk/edit?tab=t.0)

US ENGLISH\!

* o not ou spellings  
* z not s spellings  
* Collective nouns are usually treated as singular e.g. The team is playing (not ‘the team are playing’, as in British English).  
* If copy is specifically for a US audience, express the date in US style: mm/dd/yyyy or month day, year (e.g. 01/14/2025 or January 14, 2025). If the day of the week is included, use a comma after, e.g. Tuesday, January 14, 2025\.  
* Learned not learnt  
* Spelled not spelt  
* Practice (verb and noun) not practise  
* Program in all contexts (not programme)  
* ‘Different from’ or ‘different than’ (not ‘different to’ — this is acceptable in British English only)  
* Use ‘students’ rather than young people. Do not use ‘pupils’ as it is not commonly used in US English.  
* ‘Learning management’ preferred to ‘classroom management’ (for ExpCS only \- classroom management still okay for Code Editor, for example)  
* Use a comma after Latin abbreviations like e.g., and i.e.,

Tone  
Aim for a friendly, direct and casual tone. Avoid more formal or indirect, polite phrasing. For example:

* Switch ‘How might you XYZ’ to ‘How could you…’ or ‘How would you…’ Where appropriate, the more direct ‘Can you XYZ’ or ‘verb XYZ’ works.  
* Switch ‘in order to’ to just ‘to’ or ‘so’.  
* Use ‘can’ rather than ‘may’ for student-facing and less formal materials (ignoring the oft-cited rule about can/may). 

### Experience CS units

Unit names use sentence case. Use sentence case for all other headings and lesson names.

Unit and lesson names should use colons, not dashes (e.g. ‘Lesson 4: Exploring AI’, not ‘Lesson 4 — Exploring AI’). However, two-part titles should use en dashes, not colons (e.g. ‘Lesson 2: Creating a game in Scratch – part 1’, not ‘Lesson 2: Creating a game in Scratch: part 1’. Double check em dashes or hyphens haven’t been used).

Delete extra exclamation marks as necessary: aim for a maximum of four per page.

For projects and activities: We use the Code Editor and reference Scratch as the language (not any other variations on Scratch editor, etc.)

Use ‘activity sheet’ rather than ‘worksheet’.

Sarah’s notes on formatting etc.  
I’m seeing a lot of & in lesson titles in my unit \- I’m switching them out for “and” like normal  
I’m putting all bullet dots in the lesson plan in red (cd2355) \- this has been changed back to black, so probably not going to be how we format the lesson plans. Awaiting formal confirmation of this.  
“Language arts” are a thing. It’s not mistyped language and arts.

Formatting for UOs:

* Tables should have:  
  * Alternating white and grey (\#F3F3F3, light grey 3 in Google Docs) rows (except for the first row, in raspberry red, \#cd2455)  
  * Black lines  
* ISTE standards are bulleted, with bullet points in black  
* Page numbers should be written as Page \_ of \_ in the same shade of grey as the footer (\#666666, dark grey 3), with “Page” and “of” in bold but numbers in standard formatting

Text that has appeared in more than one UO:

* **Share your feedback at [rpf.io/experience-cs-feedback](http://rpf.io/experience-cs-feedback) to help us as we update these materials.**  
* Each of the \[number\] lessons includes opportunities for formative assessment, which are outlined in the lesson plans. The unit also includes a summative assessment, with a clear rubric to assess students’ final projects.  
* **CDLRA standards**  
  *Coming soon*  
* Resources are updated regularly — the latest version is available at [experience-cs.org](http://experience-cs.org).

This resource is licensed by the [Raspberry Pi Foundation](https://www.raspberrypi.org/) under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International license. To view a copy of this license, visit [creativecommons.org/licenses/by-nc-sa/4.0/](https://creativecommons.org/licenses/by-nc-sa/4.0/).

Standard text for lesson plans:

* Please note that the slide deck labels the activities in the top right-hand corner to help you navigate the lesson.   
    
* **Share your feedback at [rpf.io/experience-cs-feedback](http://rpf.io/experience-cs-feedback) to help us as we update these materials.**

**CSTA Standards [https\://csteachers.org/k12standards/interactive/](https://csteachers.org/k12standards/interactive/)**   
	Standard are formatted as 1B-AP-08  
Common Core Standards [https\://www\.thecorestandards.org/](https://www.thecorestandards.org/)  
	Check the numbering. They should be formatted as RL.4.3, W.4.3 etc.  
National Core Arts Standards [https\://www\.nationalartsstandards.org/](https://www.nationalartsstandards.org/)  
Check the numbering. They should be formatted as MA:Cr3.1.4a, MA:Cn10.1.4.a (double check there are no extra colons or extra full stops)  
ISTE [https\://iste.org/](https://iste.org/)  
	The name of the standard is in title case.  
	The standard numbering is formatted as 1.5.c  
College, Career, and Civic Life (C3) Framework for Social Studies State Standards [https\://www\.socialstudies.org/system/files/2022/c3-framework-for-social-studies-rev0617.2.pdf](https://www.socialstudies.org/system/files/2022/c3-framework-for-social-studies-rev0617.2.pdf)

* The name of the standard is in title case (as above).  
* The standard numbering is formatted as D2.Geo.1.K-2, D2.His.3.6-8 etc.  
* In the above PDF, there’s generally a final dot at the end of the standard numbers (e.g. D2.Geo.1.K-2.) — this is punctuation, not part of the standard name/number as it changes to a colon on page 94\. Feel free to punctuate in our style (with a colon).

Next Generation Science Standards (NGSS) [https\://www\.nextgenscience.org/](https://www.nextgenscience.org/)

* The name of the standard is in title case (as above). Include the acronym even if it is not used elsewhere in the UO.  
* The standard numbering is formatted as 3-ESS2-1 etc.  
* In the standards, there is generally a dot at the end of standard numbers (e.g. 3-ESS2-1.), but there is no need to retain the dot — use a colon in the table in the UO, like references to other standards

Note: Full stops at the ends of single-sentence standards can be removed when such standards are written in a bulleted list with other single-sentence standards (most, if not all, standards do seem to be single sentences).

References to Scratch:

* Capitalise references to menus, e.g. “using Looks and Control blocks”  
* Use lower case for blocks themselves, e.g. “Introduce the repeat block and the next costume block”  
* Areas within the Code Editor: programming area (where students code), Stage, sprite pane (where students select sprites etc.), Costumes tab, Sounds tab  
* Paint tools: [see slide 23 of Lesson 4.1.1](https://docs.google.com/presentation/d/13DVcpotjBmVPVUwMVto2bi2WgtUG3rCgSgkgWgkBuHY/edit?slide=id.g3435cfa0c67_0_7#slide=id.g3435cfa0c67_0_7) 

### Experience CS training

* Experience CS 'train the trainer' program. Note capitals and single quotes. Avoid the acronym 'TtT'.  
* A person who has taken the training may become a contractor with us under the title Experience CS Trainer

## Online courses (updated Sept 2025\) {#online-courses-(updated-sept-2025)}

Product strategy with agreed vision, elevator pitch, and target audience (the copy in this does not have to be used verbatim, but what we say about the product should align with it):   
[Online Courses - Product Strategy](https://docs.google.com/document/d/14_WN6X3B3sq2Xq73V0YZ6MLGe8-IEVM7Vp9NEO9AdVU/edit?usp=drive_link)  
The ed dev team's style guide for reference around the Training Hub and new features: [Ed Dev style & terminology guide](https://docs.google.com/document/d/10WdvzKG6T61LbeZp_5Rc33_N6hZWHuOMh3Gr-he5gis/edit?tab=t.0)

As online courses are generally edited in GitHub, here’s some general guidance for how to format headings etc in Markdown: [Markdown Cheatsheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet) 

| Important information\!   You can’t use colons in collapse title headings — it breaks the build\!  Collapse titles look like this, i.e., there’s already a colon\!  ![][image1] |
| :---- |

**Notes about courses still on edX**

* “edX” is a trademark and should be used as an adjective, not as a noun (e.g. “edX platform”, “edX courses”)  
* Ignore “Index” page, as no longer being used  
* Leave licence information (info about CC licence and Raspberry Pi logo) as it is   
* Subheadings on the course info page (e.g. “Long description”, “Frequently Asked Questions”) will not be visible on edX — the text below is being copied from the GH page into a form  
* In the ‘activities’ steps (e.g. ‘Week 1 activities’), the alt text for the images must be no longer than 250 characters  
* Some links to images/resources still contain mention of FutureLearn, the previous MOOC platform we hosted courses on, for example,  [https\://rpf-futurelearn.s3.eu-west-1.amazonaws.com/](https://rpf-futurelearn.s3.eu-west-1.amazonaws.com/). I checked this with Michael C and he said that they can’t change this without changing all of the URLs across all of our courses and without breaking links in the archived FL courses. So we’re stuck with it.

**RPF online training platform**  
This is called Training Hub. If you need to refer to it being an RPF product, use “the Raspberry Pi Foundation’s Training Hub”.

**Course structure**

* Courses are divided into modules (not weeks, as was formerly the term). 'module' is lower case. Subsections of modules are called ‘sections’ (module \-\> section \-\> step).  
* ~~Intro/Outro: Every module has a ‘Welcome to’ step and an ‘End of’ step. I have formatted the headings of these as follows:~~  
* ~~Welcome to the course~~  
* ~~End of module 1~~  
* ~~Welcome to module 2~~

**Reference to other steps/modules**  
Sometimes, you’ll get something like “As you saw in module 1…” in the main text. However, we should avoid referring to previous/later steps by number as the learners may not see the different pages as numbered steps.  
NB: Potentially, step numbers may not be used in the new platform — refer to ed dev style guide for reference

**Course titles**

* Use sentence case, with a capital letter after the colon, if included (in the *Teach computing: Introducing physical computing* course …)  
* If the full title is referred to within body text, use italics  
* After first use, titles can be abbreviated to their subtitle (In the *Introducing physical computing* course …)

**Calls to action**  
Most steps end with a call to action (CTA), encouraging the participants to add comments related to the discussion. This is formatted in bold.  
For consistency, I’ve only been putting the “Share your thoughts/ideas/etc.” bit in bold otherwise you will sometimes get an entire paragraph in bold. 

Some examples (please add more if you find some interesting ones):

Example 1  
Is there anything this week that you found particularly surprising, or found difficult to understand? **Let us know in the comments\!**

Example 2  
Discussion

* Do you think general intelligence should be the aim of AI research?  
* Which do you think would be more useful to society? and why?  
  * A supercomputer able to answer all of our questions...  
  * An interconnected network of hyper-specialised machines...

**Share your thoughts in the comments section.**

Example 3  
**Discussion**  
In the comments section, **share examples of some real-life scenarios** where the different types of repetition occur.

Note: In example 3, the Discussion section only has one sentence, so if the whole sentence is bold, the whole section would be in bold, which looks odd. So here's a scenario where it's best to just bold the CTA.

As the format of the CTA is so varied, this seems like the simplest way of being consistent. Also, I’ve included a full stop (in bold) even when the CTA stands on its own.

**Steps within steps**  
Sometimes, a step will consist of a list of actions/instructions the learner has to take/follow. These are normally given headings with Step 1, Step 2, etc. I’ve been using colons to separate step number and heading as it saves me having to copy and paste an en dash into GitHub and avoids formatting errors when switching between platforms. E.g.   
Step 1: Import the data set  
Step 2: Inspect the data

**Instructions relating to other websites**  
Any instructions relating to clickable buttons, options, menus should be formatted in single quotes.  
For example:

* Start by navigating to [Machine Learning for Kids](https://machinelearningforkids.co.uk/) and select ‘Get started’.  
* From here, you can log in to your account if you have one, alternatively you can complete this activity without logging in by selecting ‘Try it now’.  
* You'll now be faced with a page entitled Your machine learning projects. From here, select ‘Copy template’ from the right-hand side of the page.

**Discussion section**

* Refer to simply as ‘the discussion’ (not discussion section, box, tab, etc.)

The approach differs within edX and will also be different again on the Training Hub. Refer to the Ed Dev team's guide for now [Ed Dev style & terminology guide](https://docs.google.com/document/d/10WdvzKG6T61LbeZp_5Rc33_N6hZWHuOMh3Gr-he5gis/edit?tab=t.0#bookmark=id.phhnbuav7mbx)

**References to people**

* We \= the Foundation/RPF team. Avoid we \= the course writer \+ people completing the course (e.g. ‘In the next module we will explore …’; use ‘you will explore’ instead)  
* I \= the course writer   
* You \= the learner (singular)  
* Avoid the term ‘peers’ (C1 term). Instead, use wording like ‘fellow learners’ (preferred), ‘the other educators on this course’, ‘the people learning alongside you’, etc.

**Terms to avoid**  
For online courses, generally we avoid:

* Class → lessons; when learning (rather than ‘in class’)  
* Classroom → learning environment, context  
* Click (i.e. click this link) → select  
* Students → learners, young people  
* Teachers → educators; adults who work or volunteer with young people

## Research \- Sarah {#research---sarah}

We conduct formal research to deepen our understanding of how young people learn about computing. We also conduct impact evaluations to understand how our products reach the audiences and goals we’ve set out to meet. In our comms, we differentiate the two by reserving the term 'research' for academic studies and ‘evaluation’ for impact studies. ‘Research’ has a purpose that is wider than understanding what the RPF does as an organisation. Although ‘evaluation’ is arguably a form of research, this distinction is helpful to make when communicating externally.

**Seminar proceedings**  
Design of proceedings chapters for Vol. 4:

* First page: name and affiliation after chapter title, on same line (unlike in Vol 3\)  
* Second page: name and affiliation after chapter title, on same line, in red  
* “Raspberry Pi Foundation Research Seminars” centred at top of page, in black (unlike in Vol 3\)  
* Numbers at bottom of page, centred, in black (unlike in Vol 3\)  
* Footnotes: text in black, links in red  
* Captions for figures/tables should have a full stop, not a colon, after the figure/table number. They should also end with a full stop.  
* References in APA style  
* Check links as Adobe puts them in automatically, and sometimes they’re cut off with the line breaks  
* Author bio: name in red, no title, followed by affiliation on next line, then name with title (Dr or Professor, if applicable) in black and in bold on first line of bio

## Research to practice — Quick Reads {#research-to-practice-—-quick-reads}

[A list of all Quick Reads](https://docs.google.com/spreadsheets/d/1rvvgxERRVVfUj-Gn9Grfnor1ocwZmseg1pTY_-Zq7Pg/edit?gid=0#gid=0), sortable by name or number, with links

## Training slide decks {#training-slide-decks}

The colour for headings/red text is \#CD2355 (it should be one of the options under custom – hover and check the number)

# Section 2 – Word list {#section-2-–-word-list}

For those that need a reminder (me\!)  
Adjective \- A word naming an attribute of a noun, such as sweet, red, or technical.  
Adverb \- A word or phrase that modifies or qualifies an adjective, verb, or other adverb or a word group, expressing a relation of place, time, circumstance, manner, cause, degree, etc. (e.g., gently, quite, then, there).

### \#\#\#

3...2...1...Make\!  
3D  
3G, 4G, 5G (phone networks)  
50-50 – not fifty-fifty  
7-inch screen  
8-bit microprocessor  
8×, 16× (CD or DVD drive speeds) – note multiplication symbol, not letter x.

### AAA

A level (noun and adjective) – not A Level or A-level. She teaches computer science to her A level students. See for example this [DfE documentation](https://www.gov.uk/education/as-and-a-level-changes-and-reforms).  
A level computer science – always lower case, in line with [DfE documents](https://www.gov.uk/government/publications/gcse-computer-science)  
AA batteries  
abandonware – old software, where the IP holders are unknown  
Acorn Archimedes (computer) – shorten to Archimedes after first use  
Acorn Computers (company name, produced the BBC Micro and the Acorn family of computers)  
Acorn Electron (computer)  
adapter  
add-on; use 'add-on board', not 'card'  
adware  
affect vs effect: Affect (verb) \- Have an effect on; make a difference to; influence. Effect is mostly used as a noun, or means “to bring about” if used as a verb. For example: Once you have effected a revolution, it can be very hard to affect and it may not have the effect you intended.  
after-school  
aka – not 'a.k.a.' or 'AKA'  
all-expenses-paid trip  
AMD (company name)  
Amstrad (company name)  
Amstrad CPC (computer), short for Amstrad Colour Personal Computer  
analogue  
analogue to digital converter – when spelt out in full, do not use hyphens, to match AQA specs (not mentioned in OCR specs)  
Android (e.g. phone)  
antenna (pl. antennae)  
anti-bullying  
anti-malware  
antivirus  
app – short form of application. Don’t use if there's potential for confusion  
Apple – Apple trademark. Do not add an s to make plural  
application program interface (API)  
applications processor  
applied AI  
apt \- Advanced Package Tool, used in Debian Linux to obtain software (APT is not really an acronym. It was originally, it's just 'apt' now.)  
Arch Linux  
ARM architecture  
ARM chipset  
Arm Holdings (company name) — rebranded from ARM  
ARMv6, ARMv7  
AS level – see 'A level'  
ASCII/extended ASCII  
assembly language  
Astro Pi — find the style guide specific to this programme [here](https://docs.google.com/document/d/1-aBF_K6UYegHeBYE-d_k0xC02nzjrFPMkz_rvd-j3ZI/edit?usp=sharing). The [previous](https://docs.google.com/document/d/1cZFRJiBbAKol8LrtPgm8vMZUzs8HLZCl4pY3Heu6xNQ/edit?usp=sharing) style guide contains info on the website and twitter accounts  
Atheros (chipset, company name)  
audio conference  
auto-mark  
Auto-Tune (capitalise – it's an Antares Audio Technologies trademark. Do not use as a verb.)  
avatar (lower case unless you're talking about the movie\!)

### BBB

B.C. – place after the year. The hoard dates back to around 700 B.C.  
back end (noun), back-end (adjective)  
back-to-school (adjective), back to school (noun)  
backdoor – one word when it's a computer-hacking term  
backlight  
backlit  
backup (noun, adjective), back up (verb)  
bar code  
base \[\] (noun), base-\[\] (adjective) – e.g. ...in the base-10 numbering system, and what they think the multipliers will be in base 2\.  
Bash (Bourne-again shell)  
Bayer filter  
BBC BASIC – not BASIC (to avoid confusion with Sinclair BASIC and other BASICs)  
BBC Micro  
BBC Model A  
BBC Model B  
Bcc – blind carbon copy. Do not spell out this acronym. (See also Cc.) Also: Bcc'd, Bcc'ing.  
BCM2XXX (eg BCM2835, BCM2837, BCM2711) – SoCs made by Broadcom, used in Raspberry Pi computers. Can be shortened to 2835, 2837, 2711 after first use.  
BCS, The Chartered Institute for IT – rather than the British Computer Society; can be shortened to BCS following first use of unabbreviated name.  
Beagle Board  
beta – do not capitalise unless part of an official product line. early beta access to Isaac Computer Science; try Yahoo\! Messenger Beta  
BGA – ball grid array  
biannual, bimonthly, biweekly – do not use. Instead use every two months or twice a month etc. which is longer, but which avoids confusion.  
biased  
Big Data – to match AQA specs  
billion – use numerals with billion: 5 billion people. Abbreviate to bil only if space is at a premium.  
binary  
binary 1/binary 0 – write the digit, not the number  
binary blob – a pejorative term in the free software community. Do not use to refer to the GPU in Raspberry Pi computers.  
BIOS – Basic Input/Output System  
bitstream  
black box testing  
BlackBerry – a Research In Motion (RIM) trademark, so note capitalisation, plural: BlackBerry. BlackBerrys is not correct and can be used only as part of a direct quotation.  
blog  
Blogger – Google trademark when referring to the blogging platform  
blogroll  
Bloom's taxonomy  
Blu Tack (noun) \- A Bostik product. Blu-Tack (verb) \- 'to Blu-Tack'/'Blu-Tacked'. "Sticky tack" preferred in NCCE comms.  
Blu-ray Disc – a Blu-ray Disc Association (BDA) trademark, so note capitalisation and hyphen. Use as an adjective only.  
Bluetooth – Bluetooth SIG trademark. Note capitalisation and only use as an adjective.  
BMP – bitmap  
bookazine – publishing industry jargon, do not use this in public-facing copy. Use book.  
Boolean logic  
boot ROM \- a small piece of memory containing the first code executed by the processor on startup  
bps – bits per second  
breadcrumb (when referring to website navigation)  
Broadcom  
brute-force – adjective, as in brute-force attack  
BSD – Berkeley Software Distribution

### CCC

C (language)  
C\# (language)  
C++ (language)  
Caesar cipher  
Camera Module / Camera Module v2 \- the official Raspberry Pi camera add-on  
camera phone  
CAPTCHA – Completely Automated Public Turing Test to Tell Computers and Humans Apart. A rare instance where the first use of an acronym does not need spelling out\!  
CAS – Computing at School  
cast – As in the variable can be cast to a string, for example. The past tense is cast. Not casted. The variable was cast to a string, for example.   
Cat – for categories of Ethernet cable; note capital  
Cc – carbon copy. Do not spell out this acronym. (See also Bcc.) Also Cc'd, Cc'ing.  
CD – compact disc. Do not spell out this acronym. Plural CDs.  
CD-R – CD-recordable. Plural CD-Rs.  
CD-ROM – CD-read-only memory. Do not spell out this acronym. Plural CD-ROMs.  
CD-RW – CD-rewritable. Plural CD-RWs.  
Celsius – can always be abbreviated to °C  
centimetre (not centimeter)  
Certified Educator (Picademy graduate)  
CGI – computer-generated imaging or common gateway interface or computer graphics interface. Be clear in the first reference in a section which you are referring to before reverting to the acronym.  
champion \- lower case, including in the context of CoderDojo ("Thank you to all our wonderful CoderDojo champions and mentors\!")  
chat room  
cheat sheet  
check digit  
checkbox  
children's  
click – usage depends on the object: use click for a button, link or other interface object, and click on for pictures, icons etc.  
clickable  
client/server – an adjective to describe a kind of network  
clip art  
closed-form question  
cloud-based  
cloud computing (noun and adjective)  
cm – centimetre. Use a space between the number and cm. My thumb measures 4 cm.  
CMOS (complementary metal-oxide semiconductor) – add a hyphen before ‘semiconductor’ if adjective (e.g. CMOS (complementary metal-oxide-semiconductor) memory circuit)  
co-domain – to match AQA specs  
Code Editor – refers to our code editor. Can be shortened to “Editor”.  
codealong  
codebase  
codec – coder/decoder  
CoderDojo \- refers to the network of coding clubs that we run. Can also be used to refer to a particular club that is part of the CoderDojo network but we try to avoid this usage (see Dojo and CoderDojo vs Dojo above)   
cognitive load theory  
command line  
Commodore 64 (computer)  
Commodore Amiga – shorten to Amiga after first use  
Commodore International – company producing the Commodore family of computers  
Compute Module, Compute Module 3, Compute Module 3 Lite \- CM1, CM3, CM3 Lite. Abbreviations should only be used after first using the full product name, and only where repeating the full name would become cumbersome.  
computer science (not computing science) — always lower case, even when referring to the school subject  
computing — always lower case, even when referring to the school subject  
Computing Hubs – note capitals, e.g. We will also be working with Computing Hubs  
consent – only to be used in relation to collecting data if it is ‘Opt-in’. For GBIC, it is opt-out so should not use this term  
cookie – lower case for both biscuits and tracking cookies  
corrupted – use corrupted, not corrupt when describing data. The file is corrupted.  
Count-controlled iteration  
crawl – fine as a transitive verb meaning "to sift through" when applied to search engines  
Creative Commons licence  
cron – time-based job scheduler in Unix-like computer operating systems  
crontab – cron table, a configuration file driving cron that specifies shell commands to run periodically on a given schedule  
CSS – Cascading Style Sheets. Note capitalisation. Lower case style sheets can be used to refer to CSS documents: Cascading Style Sheets (CSS) specifications enable a web designer to use style sheets to lay out a webpage.  
CSV – comma-separated values  
curriculum (pl. curricula  
cyber- – avoid as a prefix where possible: dated. If you do need to use it, don't hyphenate. Cyberattack, cyberterrorism, cybersecurity.

### DDD

data – treat as a singular noun. The data is lost.  
data link  
data protection team (we do not have a data protection officer)  
dataset  
data type – two words  
database  
Debian  
Deepfake (no hyphen)  
Department for Education — not DfE (see https\://raspberrypifoundation.slack.com/archives/CDHCAQ7SA/p1560504856246200 )  
Device Tree: a means of representing devices on Raspberry Pi- see the original elinux documentation here.  
dialog box – US spelling for this technical term. Otherwise use 'dialogue'. Except: TCC content, then use dialogue box.  
differentiation – avoid this term in high-level content  
digital age, digital native, digital divide – avoid where possible. Dated jargon.  
Digital Making Curriculum. Also: the Raspberry Pi Foundation's Digital Making Curriculum.  
Dijkstra’s algorithm  
dingbat – typographical ornament, such as ★.  
disc/disk – magnetic storage is on disks, but optical storage is on discs: floppy disks, compact discs.  
distributed denial-of-service (DDoS) attack  
divide by zero error  
Document Object Model (DOM) – note capitals  
Dojo \- upper case. Used to refer to a particular club in the CoderDojo network  
Domain Name Server (DNS) — lower case ‘domain name’ if general usage of the term  
dongle  
DoS – denial-of-service attack  
DOS – Disk Operating System. Acronym for several closely related operating systems.  
dos and don'ts – note apostrophes  
double-click – note hyphen  
drag-and-drop (adjective), drag and drop (verb)  
dreamt  
drop-down menu not pull-down menu  
DVD – digital video disc. No need to spell out the acronym in first use.  
DVR – digital video recorder  
Dynamic Host Configuration Protocol (DHCP)

### EEE

\-esque – Do not hyphenate words with this suffix unless the suffix creates a double vowel. Turneresque, Dali-esque.  
e- – generally, hyphenate when a prefix. So: e-book, e-card, e-reader. Note exception for email, esports.  
e-book  
e-commerce  
e-paper  
e.g.  
Earth – capitalise when referring to planet, lower case when referring to soil.  
eBay – an eBay trademark  
Ed and Izzy \- the two special Astro Pi units sent to the ISS with Tim Peake.  
EEG \- electroencephalography  
element14/Premier Farnell in the first instance in a chapter section, then just element14. Element14 should be capitalised if it appears at the beginning of a sentence; in general, try to avoid using at the start of a sentence.  
email  
emoji – pl. emojis (even though this word is Japanese; see tsunami, tsunamis)  
Emotiv – company producing EEG headsets for neuro-signal work.  
end-of-file marker  
end-of-unit test  
end-of-year \- adjective before a noun, as in 'end-of-year report'  
EPROM – erasable programmable read only memory  
ePub – electronic publication. An open-standard file format for e-books.  
ESP – email service provider  
esports  
etc.  
Ethernet (always capitalise)  
EULA – end user licence agreement  
evaluate – please see the ‘Preferred terms’ section for notes on usage  
ex. – do not use this abbreviation. Use e.g. instead.  
Exif (file format)  
explorer task/activity

### FFF

f-score – in context of A\* search algorithm  
Facial detection (in US context; not facial recognition)  
fact sheet  
fact-based model (Big Data)  
Fahrenheit – can always be abbreviated to °F  
fan page  
fan site  
fanbase  
FAQ – frequently asked questions. Plural FAQs.  
fax  
feed reader  
Feedback — “give feedback”, but “feed it back to the class”  
felt-tip pen  
fetch-decode-execute cycle \- Except: Fetch-Execute cycle, to match AQA specs  
fibre-optic (adjective), fibre optics (noun)  
file name  
file system  
film-makers, not filmmakers  
firewall  
FireWire – trademark  
fixed-point binary  
Flash – do not capitalise Flash when referring to flash memory. If for some reason you need to refer to the now-deprecated Adobe Flash, use Flash as an adjective, since it is a trademark.  
flash memory  
flat file databases  
flip chart  
floating-point \- adjective, as in 'floating-point number'  
forgo – not forego  
formulas (not formulae)  
friend – can be used as a verb if referring to social networking, but this is grim and unlovely. See unfriend.  
front end (noun), front-end (adjective)  
FTP – File Transfer Protocol (note capitalisation)  
full-screen  
function keys

### GGG

g – gram(s). Use a numeral with g and no space between the numeral and g. The teabag weighs 7g.  
G Suite – brand name  
Gameboard  
gamer  
Gb – gigabit. No space between the number and Gb.  
GB – gigabyte. No space between the number and GB. You'll need an 8GB SD card.  
GBIC Schools Network  
Gbps – gigabits per second. No space between number and Gbps.  
GBps – gigabytes per second. No space between number and GBps.  
GCSE to A level – do not hyphenate  
gender balance (never gender gap)  
Gender Balance in Computing programme (of research)  
general purpose computer – from AQA specs  
Generation X – not Generation Xer  
Generation Y – this used to be the term of art. Since this style guide was conceived the term millennials has been coined and is now dominant in the culture. Feel free to use it.  
geolocation  
geotagging (noun – OK, gerund), geotag (verb)  
GHz – gigahertz. No space between the number and GHz.  
GIF – Graphic Interchange Format. Acronym is always OK. Plural GIFs.  
GitHub  
GNU – the GNU Project. A recursive acronym: GNU is not UNIX.  
GNU Linux  
Google – Google trademark. Google's guidelines say you may not use the trademark as a verb, but common usage says we can ignore them wholesale on this. It's in the OED. That's good enough for me. Try to avoid it in NCCE comms, though. The DfE still says we can't google stuff.  
GPIO – general-purpose input/output. Individual GPIO pins are named in bold: **GPIO 4** (not ‘GPIO pin 4’, ‘pin 4’, ‘Pin 4’ etc. as this may cause confusion with board numbering), **3V3**, **5V**, **GND**.  
GPIO Zero – GPIO Zero is the name of the project, but gpiozero is an acceptable alternative when referring to the module  
GPU – graphics processing unit  
grade – for school grades (USA), spell out first through ninth grade and use figures for 10th grade or higher. Try to keep a consistent format for ranges (see Numerals and numbers above).  
gram – see g  
grey – not gray  
grown-up \- the noun takes a hyphen; it isn't grownup  
GSM – Global System for Mobile Communications  
guestbook  
GUI – graphical user interface  
guizero

### HHH

HackSpace magazine – Note capitals. It is no longer the case that we must always include magazine when referring to it.  
half term – half a school term  
half-term – holiday between half terms  
half-termly — in a half term  
Halting problem — from AQA specs  
hand-trace algorithms — AQA specs  
hard disk – from AQA specs  
Hardcore  
Harshad numbers  
Harvard machine  
hashtag – Twitter term  
HAT \- Hardware Attached on Top, describing various add-on boards such as the Sense HAT  
HDTV – high-definition television  
head teacher  
heatsink \- not heat sink  
help desk  
help pages  
higher-order function – to match AQA specs  
historic vs historical – note that these are not synonyms: ‘historic’ means important or likely to be important in history, while ‘historical’ means related to things from the past (e.g. for Mission Space Lab, teams can access historical data to test their programs)  
hit – do not use as a substitute for press or click  
home page  
host name  
hot swap (noun), hot-swap (verb), hot-swappable, hot swapping  
hotspot – one word when referring to a Wi-Fi access point. Use hot spot if you're talking about a popular restaurant.  
hover – do not use to describe holding a mouse pointer over something on the page. Use hold, pass, or move \[your mouse cursor over\].  
HTML – Hypertext Markup Language  
HTTP/HTTPS (when referring to the protocols themselves)  
humanlike (one word)  
Hynix (company name)

### III

i.e.  
I2C \- Inter-Integrated Circuit, used for peripherals on Raspberry Pi; use I2C (no superscript) unless there's a particular reason for using I2C (changed Nov 2020 and consistent across RPTL and Raspberry Pi Press)  
IBM – company name  
IC – integrated circuit  
ICT – information and communications technology, not information and communication technology  
ID – identification. Plural IDs. Avoid using as a verb unless space is very restricted; use apostrophe in verb form. Where possible, The bouncer checks drinkers' identification, not The bouncer ID’s drinkers.  
IDLE \- Python IDE installed on Raspbian, found under the Programming menu as 'Python 3 (IDLE)'  
IEEE Working Group  
if, else statement — in TCC text (may also be if, then, else statement)  
IM – instant message. Plural IMs. Defunct. Use DM or PM instead according to context.  
IMAX – trademark, so use as an adjective, not a noun  
inbox  
index – plural: indices, not indexes (esp. in technical contexts)  
infrared  
Inkjet  
In-person (or in person if not before a noun) — Activities where attendees are present in the same physical location (schools or libraries for example) at the same time (often used in contrast to ‘online’)    
install – install on a computer, install to a hard drive  
internet (do not capitalise unless at start of sentence or in title case)  
internet exchange point (IX)  
Internet of Things (IoT)  
Internet Protocol suite  
internet service provider  
intervention – avoid, use ‘project’ instead  
IP – Internet Protocol or intellectual property (note capitalisations)  
iPad – Apple trademark, so do not add an s to make plural  
iPhone – Apple trademark, so do not add an s to make plural  
iPod – Apple trademark, so do not add an s to make plural  
IR – infrared  
Isaac Computer Science  
Isaac Computer Science event nomenclature — note capitalisation: 'Student Discovery event / Student Booster event / Student Masterclass event / Teacher CPD event' in the first instance, thereafter 'Student/Teacher' should be dropped ('session' instead of 'event' is acceptable if it's necessary avoid repetition)  
ISP – internet service provider  
IT – information technology  
Java – a Sun Microsystems trademark  
JavaScript – a Sun Microsystems trademark  
JPEG – Joint Photographic Experts Group  
junk mail

### KKK

k – do not use as an abbreviation for thousand. When talking about kilobytes, use kB, not k, which is outdated. The original BBC Micro had 32kB memory.  
kb – kilobit. No space between the number and kb.  
kB – kilobyte. No space between the number and kB.  
kbps – kilobits per second. No space between the number and kbps.  
kBps – kilobytes per second. No space between the number and kBps.  
key press  
key stage – no capitals; use with digit instead of spelled-out number, e.g. key stage 3; abbreviate without a space, e.g. KS3  
keylogger  
keyword – search engine term. Think about the best keywords to use on your webpage. Use key word when referring to a critical word. She couldn't remember what else he'd said. The key word in his last sentence was "bagpipes".  
kg – kilogram(s). No space between number and kg.  
kHz – kilohertz. No space between the number and kHz.  
kids'  
km – kilometre. No space between the number and unit. We drove 50km.  
kmph – kilometres per hour. No space between the number and kmph.

### LLL

l – litre. No space between the number and l. Lower case. The barman served drinks in 1l glasses.  
LA – Los Angeles. Use only when space is at a premium.  
ladies'  
LAN – local area network  
layer 3 switch  
LCD – liquid-crystal display. Plural LCDs.  
‘Learners’ is our preferred term, rather than ‘pupils’ or 'students'. Except: GBIC comms, where 'pupils' is preferred. Learners does not restrict us to formal settings as anyone can learn at any point, compared with students and pupils, which are more closely associated with a school or formal education setting/structure. However, use a mix of terms if 'learners' is getting repetitive and the other terms describe your audience suitably. The thinking on this changes regularly, so let your friendly copy editing team know if you prefer a different term.  
learning graph – always preferred to objective graph  
learnt  
LED – light-emitting diode. Plural LEDs.  
left-hand \- adjective. Use 'top left-hand side', not 'top left side' or 'top-left side'  
legitimate interest – the basis on which GBIC is collecting and storing data (not consent \- see above)  
Lego – the Lego Group has trademarked LEGO (all caps) and LEGO should be used to refer to specific LEGO products, or within Build HAT projects. Lego is an acceptable usage for passing reference to Lego or similar products in other materials. See also splot. Adjective only. Plural Lego bricks, not Legos, which is an abomination unto Nuggan.  
LEGO® Education SPIKE™  
LEGO® SPIKE™  
LEGO® Technic™  
levels of abstraction  
LGBT – lesbian, gay, bisexual, transgender  
Li-ion – lithium-ion (a kind of battery)  
licence/license – licence (noun), license (verb) (unless US English, then license for both)  
like – when using as a Facebook verb, enclose in quotation marks. Thousands of people 'like' Raspberry Pi on Facebook, helping the charity to raise funds. If producing online materials and treating the term as a user-interface object (viz. as a link or a button), use a hyperlink to make it stand out, and do not use quotation marks.  
Linux – trademark owned by Linus Torvalds. Not capitalised in the same way as UNIX.  
LiPo – lithium polymer (a kind of battery)  
lithium-ion – do not capitalise when written out in full (cf. Li-ion)  
live coding  
livestream – one word when a noun. Two words when used as a verb  
logic 1/logic 0 – write the digit, not the number  
login – one word when a noun or adjective. Two words when used as a verb. However, try to avoid using as a verb; sign in is preferable because it sounds less technical.  
Logo – programming language  
lookup – one word when a noun or adjective: lookup table or reverse phone number lookup. Two words when a verb. I tried to look up the length of my ex's prison sentence.  
LXDE – Lightweight X11 Desktop Environment

### MMM

m – metre. No space between the number and m. The sausage measured an amazing 6m.  
Mac (for Macintosh) is acceptable usage  
MacBook, MacBook Air, MacBook Pro – Apple trademarks, so do not add an s to make plural  
machine – do not use as a synonym for computer. Use computer.  
macOS (not Mac OS, Mac OS X, OS X, or OSX)  
mailbox  
maker movement – not Maker Movement. Just stop that.  
maker space \- this is preferred, but if the specific organisation calls itself a makespace, hackspace or maker shed, use their verbiage when referring to them.  
malware  
markbook – ICS  
mashup (noun, adjective), mash up (verb)  
matrix, pl. matrices  
Mb – megabit  
MB – megabyte (not MByte). No space between the number and MB. My old Amiga only had 130MB drive space.  
Mbps – megabits per second. No space between number and Mbps.  
MBps – megabytes per second. No space between number and MBps.  
Mealy machine — a type of finite state machine  
meetup (noun)  
media – treat as a mass noun with a singular verb. The media is paying a lot of attention to Raspberry Pi. However, if you can distinguish a number of individual mediums making up the use of media, use a plural verb. Various media are treating the story differently: print newspapers are not paying much attention, but the TV news and online news sites are very interested.  
membership – one has, applies for, pays for, gives, etc. membership of a club, society, association etc.  
Memorandum of Understanding (MOU)  
mens'  
mentee – never, ever use this horrible neologism. Student or protégé are acceptable substitutions.  
mentor \- lower case, including in the context of CoderDojo. Thank you to all our wonderful CoderDojo champions and mentors\!  
message boards  
metadata  
meta-skills  
metatag  
mg – milligram(s). No space between the number and mg.  
MHz – megahertz. No space between the number and MHz.  
micro HDMI – lower case if mid-sentence  
micro USB  
micro:bit – a handheld, fully programmable computer which was given free to every Year 7 child across the UK. Use ‘BBC micro:bit’ the first time it is referred to. It takes a definite article, i.e. ‘the BBC micro:bit’/’the micro:bit’. The Micro:bit Educational Foundation is trying to drop the 'BBC' in front of 'micro:bit'. If using just 'micro:bits', for example, try not to begin sentences with it, due to the lower case nature of the name. When talking about different versions of the micro:bit, write ‘micro:bit V1’ and ‘micro:bit V2’ (not ‘micro:bit v1’ or ‘micro:bit v2’).  
Micro:bit Educational Foundation – see [here](http://microbit.org/about/). Note uppercase 'M'.  
microblog  
microcontroller  
microprocessor  
microSD \- SanDisk trademark. Don't use at the start of a sentence, because that lower case 'M' is a nuisance.  
microsite  
Microsoft .Net – Microsoft's trademark guidelines say that Microsoft should precede the .Net brand name in the first instance of use. Because the full stop can create confusion, insert Microsoft before .Net if it occurs at the start of a sentence. Better still, never use the term at all.  
Microsoft Windows – see Windows  
mike – short form of microphone (mic also acceptable)  
million – use numerals and a space with million. Don't hyphenate the numeral and million, even before a noun. If you're forming a compound adjective, use a hyphen between the numeral and million. So: 4 million Raspberry Pis, a £4 million budget, a 4-million-year schedule.  
min. – abbreviation for minute; use only where space is at a premium, and note full stop.  
mind map, not mindmap  
mini USB  
miniSD – lower case unless at the start of a sentence/bullet point  
mips – million instructions per second. No space between number and mips.  
ml – millilitre(s). No space between the number and ml.  
mm – millimetre(s). No space between the number and mm.  
mobile – acceptable as a noun when it's a short form of mobile phone, but try not to make a habit of it  
money-can't-buy prizes  
moon – lower case, whether referring to the moon or other moons. Mercury does not have a moon.  
Morse code – note capitals, and no article  
mouse – plural mice even when talking about computer peripherals  
mouseover, mouse over – do not use. Use roll or move your mouse cursor over, or an equivalent.  
MP3 – abbreviation for MPEG-1 Audio Layer 3\.  
MPEG – Moving Picture Experts Group. Also refers to a compression methodology whose standards are set by this group.  
mpg – miles per gallon. No space between the number and mpg.  
mph – miles per hour. No space between the number and mph.  
MS-DOS – Microsoft Disk Operating System. Trademark for a Microsoft operating system from the DOS family. See DOS.  
multi- – do not hyphenate words with this prefix unless the root word starts with an i or a capital letter. Multiplayer, multicolour, multi-industry.  
multiple choice questions (not ‘diagnostic questions’, which is the brand)

### NNN

nano \- linux text editor. Note lower case. Full name: 'GNU nano'  
nanoswitch  
National Centre for Computing Education certificate in GCSE Computer Science subject knowledge  
National Centre for Computing Education's Computer Science Accelerator Programme  
national curriculum (cf. government website)  
National Pupil Database  
NCCE acronym should be avoided  
net – do not capitalise if referring to the internet. Use internet for preference, unless space is tight.  
network attached storage (NAS)  
network interface controller/card  
network service provider (NSP)  
newline – the control character  
news feed  
newsreader – both job title and RSS feed  
Ni-MH – a kind of battery. Note capitalisation differs on expansion; cf. nickel-metal hydride.  
NIC – network interface card  
nickel-metal hydride – see Ni-MH  
Ninja \- upper case when used in the context of CoderDojo  
no-no  
no. – when ‘number’ is abbreviated  
No. 1 – see number one  
Node-RED \- a visual tool for wiring the Internet of Things  
Node.js  
Non-digital  
NOOBS \- New Out Of Box Software, used to easily install an operating system on Raspberry Pi.  
Noughts and crosses for UK, India, South Africa, New Zealand, Australia; tic-tac-toe for US; Xs and Os for Canada and Ireland  
number one – no hyphen as adjective. Bagpipes are my number one hate. Abbreviate as No. 1 if space is tight.  
NYC – New York City. Use only if space is tight.  
Nyquist theorem – to match AQA specs (not mentioned in OCR specs)

### OOO

object-oriented programming  
objective graph – do NOT use, always use ‘learning graph’  
OEM – original equipment manufacturer. Preferable to factory when talking about the place where Raspberry Pi computers are made.  
off-screen  
offline  
offshoot  
ohm  
OK – not okay, Ok or ok. OK?  
on-screen (adjective), on screen (adverb)  
one’s complement  
online  
open source (noun), open-source (adjective). Except: NCCE comms, where "open source program" is preferred. It's wrong, but I'm not willing to pick a fight with the DfE over it.  
opt-in (noun, adjective), opt in (verb)  
organiser (s, not z)  
OS – operating system. Plural OSes.  
outbox  
overclocking (noun), overclock (verb). Never the verb clock, which may mean something else entirely. If in doubt, clarify. For example, dynamic frequency clocking.

### PPP

P2P – peer-to-peer  
Pac-Man (game)  
page view  
Pair Programming – teaching approach used in GBIC comms \> Note: This is not capitalised in any other text (e.g. FL courses, pedagogy bytes)  
parents/carers — in GBIC comms, based on feedback from schools  
Parson's Problems (apostrophe decision made because Dale Parsons referred to them as Parson’s Programming Puzzles in his paper)  
participants (not delegates or attendees)  
passcode  
passphrase  
password  
password-protect (verb)  
PayPal – an eBay trademark  
PC – personal computer. Make context clear to avoid confusion with politically correct.  
PCB – printed circuit board  
PDF (Portable Document Format, Adobe file format)  
pedagogical content knowledge (PCK) — term coined by Shulman  
Peer Instruction – teaching approach used in GBIC comms \> Note: This is not capitalised in any other text (e.g. FL courses, pedagogy bytes)  
peer-to-peer (adjective)  
percent  
Perl  
pharming – redirecting traffic from a website that looks legitimate to a spoof website  
PhD  
phishing – tricking someone into giving out sensitive information using an email that looks legitimate  
photobooth  
Photoshop – Adobe trademark. Use as an adjective or proper noun, and never as a verb.  
Pi In The Sky (PITS) board  
Picademy \- deprecated in-person training courses for teachers. If possible, pluralise by adding 'sessions', 'courses' or similar.  
picamera \- software library which provides a pure Python interface to the Raspberry Pi Camera Module. Contains the PiCamera class (among others). Note capitalisation.  
PIN – acronym for personal identification number. PIN number is tautological but acceptable.  
PiServer – a piece of software created by us for centrally controlling fleets of Raspberry Pis (e.g. in a classroom)  
playlist  
PlayStation – Sony trademark. Do not add an s to make plural.  
podcast  
PoE – power over Ethernet  
polyfuse  
pop-up (noun, adjective), pop up (verb). Not popup.  
pope – lower case unless referring to a specific named pope. The pope wants a Raspberry Pi. The Queen met Pope Benedict XVI.  
Post-it – 3M trademark. Do not use as a noun. Plural Post-it notes. "Sticky notes" preferred in NCCE comms.  
power line communication (PLC)  
Practice vs practise \- Practise (verb UK only) \-To perform an activity repeatedly to improve. Practice \- the application of an idea, belief, or method; customary, habitual, or expected procedure or way of doing of something; the carrying out or exercise of a profession, especially that of a doctor or lawyer.  
pre- – close up pre- as a prefix with the root word unless the root word starts with an e or a capital letter, in which case hyphenate. Preprandial, pre-election, pre-MP3.  
press – when talking about a key on a keyboard, use press. Click is for buttons, links and other interface elements, and click on is for the mouse action.  
Principal vs principle: Principle is normally used as a noun meaning ‘a fundamental basis of a system of thought or belief’, as in this is one of the basic principles of democracy. Principal, on the other hand, is normally an adjective meaning ‘main or most important’, as in one of the country's principal cities. Principal can also be a noun, where it is used to refer to the most senior or most important person in an organisation or other group: the deputy principal.  
print  
printout (noun), print off (verb)  
program (computer)  
programme (television, theatre etc.)  
PS2, PS3, PS4 – acceptable abbreviations for Sony's PlayStation 2, PlayStation 3, and PlayStation 4\.  
pseudocode  
pupils (not students or learners) — GBIC comms only, although can be used for primary audience, or when the audience is cross-phase. See 'Learners'.  
Puppy Linux  
PuTTY: popular SSH/Telnet software used to access Raspberry Pi  
Pygame  
Pygame Zero  
Python (language)  
Pythonic

### QQQ

Q\&A  
QR code  
quad-core \- hyphenated when modifying a noun (processor, computer, etc.)  
QuickTime – Apple trademark

### RRR

RAM – random access memory  
Raspberry Pi – plural Raspberry Pis. Do not abbreviate, however much you want to.  
Raspberry Pi Foundation accounts (as opposed to 'Raspberry Pi accounts'). Unless it's super awkward/repetitive. Abbreviating to 'Foundation account' is preferable.  
Raspberry Pi 1, Raspberry Pi 2, Raspberry Pi 3B+, Raspberry Pi 4 etc.  
Raspberry Pi Foundation  
Raspberry Pi Weekly (a weekly email newsletter)  
Raspberry Pi Zero  
Raspberry Pi Zero W (not 'Wireless')  
Raspbian  
Raspbian Lite  
re- – close up this prefix with root words unless the root word starts with an e or a capital letter. If it does, hyphenate. There are exceptions to this rule for the avoidance of confusion with other words: re-create, re-cover, re-sent.  
read-only  
read-write  
real time (noun), real-time (adjective)  
reality TV  
Research Bytes — note formatting  
Resource Repository \- Previous name for the Teach Computing Curriculum   
RetroPie – not Retropie or RetroPiE  
retweet  
RFID (radio frequency identification)  
right-click  
right-hand \- adjective. Use 'top right-hand side', not 'top right side' or 'top-right side'  
ringtone  
rock 'n' roll  
rock-paper-scissors game  
Roku – company name and name of streaming media device. Trademark. Do not add s to make plural. Plural Roku boxes or Roku devices.  
role play (noun), role-play (verb and adjective)  
ROM – read-only memory  
round-trip delay  
roundup  
rpm (revolutions per minute)  
RS Components – in full in the first instance in a chapter section, then just RS.  
RSS – Really Simple Syndication. Best practice is to use RSS feed, RSS news feed or RSS newsreader; few people know what RSS means on its own, and it's much less used in these dark days of the 2020s than it was when this guide was first written.  
RTC – real-time clock  
run length encoding – from AQA specs  
runtime

### SSS

sample resolution  
sampling rate  
SanDisk (company)  
satnav  
Scouts \- From the [Scouts website/style guide](https://www.scouts.org.uk/volunteers/running-things-locally/local-media-and-member-communications/our-brand/scouts-style-guide/scouts-style-guide/): "Some words (such as Scouts and Friday) are always capitalised. Please capitalise:

* Scouts (or The Scout Association on the very rare occasions you need to call it that)  
* Scout nouns such as Beavers, Cubs, Scouts, Explorers, Activity Badges, Wintercamp, and so on"

screen – should only refer to a computer or television screen, not a page on a website.  
screen name  
screen reader (accessibility tool)  
screencast  
screengrab  
screensaver  
screenshot  
scroll bar  
scroll wheel  
SD card – Secure Digital memory card format  
SDA – SD Card Association, developers of SD, SDHC etc. cards  
SDHC card – Secure Digital High-Capacity card  
search engine  
Secure Sockets Layer (SSL)  
security key  
setup (noun, adjective), set up (verb)  
short code – two words when referring to a mobile phone  
sidebar  
sign-in (noun, adjective); sign in, sign in to (verb). Preferable to log in or log on; sounds less technical.  
sign-out, sign-up – see sign-in  
SIM card – subscriber identity module card  
Sinclair ZX81 (cf. ZX Spectrum)  
single value element  
single-board computer  
site map  
sixth form, but sixth-form college to match gov.uk style guide  
slideshow  
smart card  
smartphone  
SMS – short message service  
snail mail – just no. Use the post or similar.  
SoC – system on a chip  
social media – treat as media  
social network (noun), social-network (adjective)  
social networking (noun), social-networking (adjective)  
SODIMM (no hyphen)  
software – collective noun; when singular, never write 'a software' (seriously, we've seen news outlets who should know better use this); always write 'a piece of software' (preferred) or 'a software program'  
solid-state disk (SSD) – from AQA specs  
sound bite  
soundcheck  
soundstage  
sound wave  
spam  
spammer  
Speech-to-text  
spell-checker, spell-check  
SPIKE™ Prime  
splot – the individual nubble on a Lego brick. A Raspberry Pi fits into a case measuring seven by eleven splots.  
spyware  
SSH  
standalone  
startup (noun, adjective), start up (verb)  
stationary \- still; stationery \- office supplies  
STEM Learning Ltd can be shortened to STEM Learning following first use of unabbreviated name  
sticky notes, not Post-it notes (Post-it is a brand)  
sticky tack, not Blu-Tack  
sticky tape, not Sellotape  
stop frame animation/stop motion animation  
Student Booster event \- note capitalisation for Isaac Computer Science event nomenclature. After the first occurrence, 'Student/Teacher' should be dropped ('session' instead of 'event' is acceptable if it's necessary avoid repetition).  
Student Discovery event \- note capitalisation for Isaac Computer Science event nomenclature. After the first occurrence, 'Student/Teacher' should be dropped ('session' instead of 'event' is acceptable if it's necessary avoid repetition).  
Student Masterclass \- note capitalisation for Isaac Computer Science event nomenclature. After the first occurrence, 'Student/Teacher' should be dropped ('session' instead of 'event' is acceptable if it's necessary avoid repetition).  
style sheet – lower case even when referring to CSS (which you probably aren't referring to, but you know. Just in case). See CSS.  
sub- – close up this prefix with the root word unless the root word starts with a capital letter, in which case hyphenate. Subdomain, sub-Victorian.  
subclass/superclass – no space. Specifically for ICS content, but in general too.  
subgoal (no hyphen)  
subheading (no hyphen)  
Subject Practitioner Panel – note capitals  
sublist (no hyphen)  
subpage  
subproblem (no hyphen)  
substring  
sync, synched, synching  
system flowchart

### TTT

T-shirt  
teachcomputing.org – Use ‘the teachcomputing.org website’ the first time it's mentioned, then ‘teachcomputing.org’ afterwards. However, use ‘the teachcomputing.org website’ in instances where it's referred to in a hyperlink to a specific page on the website, or where the reference doesn't include a hyperlink. This is the link to the NCCE website, so we shouldn’t be using it unless we actually want to link to the NCCE.  
Teacher CPD event \- note capitalisation for Isaac Computer Science event nomenclature. After the first occurrence, 'Student/Teacher' should be dropped ('session' instead of 'event' is acceptable if it's necessary to avoid repetition).  
teaching approach (not pedagogy) – in GBIC comms only (pedagogy is fine in other contexts)  
TeachMeet  
terminal \- when talking about starting the command line in the GUI, 'open a terminal window' (never LXTerminal or similar)  
Tetris (game)  
text message (noun), text-message (adjective, verb). Acceptable to shorten to text  
text-to-speech  
The MagPi \- the official Raspberry Pi magazine  
‘think, write, pair, share’ activity — depending on context, may just be ‘think, pair, share’ activity  
thousand – spell out when in inline text  
three-box model  
thumb drive  
Tic-tac-toe for US; noughts and crosses for UK, India, South Africa, New Zealand, Australia; Xs and Os for Canada and Ireland   
TikTok  
timeshift, timeshifting  
TiVo – trademark. Do not use as a verb or add an s to make plural.  
Tkinter – Python library  
to-do – plural to-dos. Capitalise as To-Do in title case.  
toolbar  
tooltip  
top-level domain  
TOS – terms of service  
touchpad  
touchscreen  
towards – not toward  
trackball  
trackpad  
trade show  
Training Hub  
Transport Layer Security (TLS)  
traveller, travelled, travelling  
Trinket \- the service provided on the trinket.io website, as well as the organisation. Note that capitalisation is used inconsistently in their website copy, so this usage is a judgement call by us. See below.  
trinket/trinkets \- projects on trinket.io. See above.  
trojan — to match AQA specs  
Trojan horse  
Troubleshoot  
‘true or false’ activity/quiz  
Turing machine  
Turing test (lower case t for test)  
TV (no need to spell out what the acronym means\!)  
tweet  
~~Twitter – Capitalise when talking about the website. Do not use as a verb to refer to communicating on Twitter. Use tweet instead.~~ Edit 27/09/23: Twitter has been rebranded to X, so depending on phrasing, it should now be referred to as “X (formerly Twitter)”.  
~~Twitter thread~~  
two’s complement

### UUU

UART – universal asynchronous receiver/transmitter  
UI – user interface  
UK  
UN  
undervoltage \- not under voltage  
unfriend – see friend  
Unicode – note capital  
Unified Modeling Language (UML)  
universal Turing machine – lower case ‘u’ (updated 14/05/21)  
UNIX  
Unplugged  
unshielded twisted pair (UTP) cable  
unsubscribe  
up-to-date  
URL – Uniform Resource Locator, but abbreviation is always OK and doesn't need to be spelt out in the first instance  
USA  
USB – universal serial bus  
USB flash drive  
Use-Modify-Create  
user  
user base  
userID  
userland – OS software that does not belong in the kernel  
username

### VVV

value of red/green/blue – when talking about RGB values  
vector graphics (not images) – in Isaac content  
VGA – video graphics array  
video call – verb and noun  
video camera  
video game  
videoconference  
videophone  
virtual LAN (VLAN)  
vlog – video blog  
voicemail  
VoIP – voice over Internet Protocol  
von Neumann architecture/machine  
VPN – virtual private network

### WWW

wallpaper, wallpapers  
WAN – wide area network  
waterfall lifecycle – according to OCR specs  
@WeAreComputing – note capitals  
web  
web browser  
web server  
webcam  
webcast  
webinar (ghastly, but it appears we're stuck with it)  
webisode (see webinar)  
weblog – use only when explaining the etymology of the word blog, which is always to be preferred  
webmaster  
webpage  
website  
Websocket protocol – in AQA spec  
Well-being — A positive state of mind and body, health, happiness, and prosperity. It enables and supports good relationships, improved resilience, improved health, meaning, purpose and control. (Adapted from UK Department of Health)  
white box testing  
white paper \- two words, lower case, as preferred by both AP and Guardian/Observer style guides (2021/07/02)  
whitespace (character)  
whole-class activity  
widescreen  
Wi-Fi (not WiFi, wifi, or Wifi) – if referring to a Raspberry Pi product, do not use this; refer to the built-in Wi-Fi as 'wireless LAN' or similar. If you are not sure whether the connected item is licensed to use 'Wi-Fi', use 'wireless LAN'. Note that "wireless" is sometimes an acceptable substitution, but "wireless LAN" makes clear that we are not referring to Bluetooth connectivity.  
Wii – Nintendo trademark. Do not add an s to make plural.  
Wiimote \- controller for the Wii. Colloquial. (The official term is Wii Remote.)  
wiki – plural wikis  
Windows – trademark: use Microsoft Windows if talking about the Microsoft product to differentiate from other windowing software  
Windows CE – trademark. Not Microsoft Windows CE  
Wine – application to allow Microsoft Windows software to run on UNIX-like operating systems. Originally an acronym for WINdows Emulator, later changed to a recursive “backronym” for Wine Is Not an Emulator.  
wireless access point (WAP)  
womens'  
word processing (noun), word-processing (adjective). Except: "word processing software" in NCCE comms  
word-of-mouth  
WordPress – trademark  
worked examples  
workflow  
World Wide Web  
WWW  
WYSIWIG – what you see is what you get

### XXX, YYY, ZZZ

X-ray  
x86 architecture  
Xbox – Microsoft trademark. Do not add es to make plural  
XHTML – Extensible Hypertext Markup Language  
XML – Extensible Markup Language

Yahoo\! – use the upper case Y and the exclamation mark when referring to the company or its brands  
Year \[digit\] — e.g. Year 6 students  
YouTube – Google trademark

ZIP code — as in AP Stylebook  
zip file  
ZX Spectrum

# 

# Section 3 – General guidance {#section-3-–-general-guidance}

## Some quick do’s and don'ts {#some-quick-do’s-and-don'ts}

No double spaces after punctuation, please\!

Use bold type for emphasis. Try to avoid using italics or underlining.

When producing any document with page numbers, the front cover should be considered as page 1\. Therefore, numbering may start as ‘page 3’ within documents.

Avoid exclamation marks if possible. Philip hates them, and Faye doesn’t like them either, so try not to overuse them. A rule of thumb would be 1 max for pieces to professional audiences, 2 max for volunteer pieces. And none in newsletter headlines.

## Images {#images}

If there are screenshots anywhere (especially in TCC slides), check that they can’t be expanded to show the rest of the screen. Sometimes, if an image is a screenshot that has been cropped, it will show the rest of the screenshot if you double-click on it. \*\***Images used for TCC references should also have a link or sentence as a reference**\*\*.

**AltTexts** must be added to images, we have a legal requirement to do so for some resources and it’s best practice. It can be the same as the caption but should ideally be more descriptive.   
Some excellent advice on [what makes a good AltText can be found here](https://docs.google.com/document/d/19tQltsQU9OwEWPrkCGm_ihwLQVd3t-9McNRWr9CTtX0/edit). 

## Images of other companies’ brand assets {#images-of-other-companies’-brand-assets}

Some content for the Applied Certificate Stage 2 Media module (CE’d in April 2026\) included examples of real campaign assets by other brands, such as a Spotify poster, a Burger King poster, a Just Eat video advert, and an innocent Drinks digital asset. These examples were used in the module content and some activities. Sometimes, we explained features of the adverts, and sometimes, learners were asked to analyse them or rearrange parts of them (for example). The Applied Certificate team had asked Legal about their use and received the following reply, which I’m pasting for future reference in case we come across similar uses in other materials:

“Under UK law, using a copyrighted work (the Just Eat advert) for the sole purposes of demonstrating a point in teaching, and for the purpose of criticism or review, does not infringe copyright. However, the content must not be used for any commercial purposes and must be accompanied by a sufficient acknowledgement i.e must be clearly attributed to the brand.

The use of the brand logos themselves (Nike, Spotify etc.) for the purpose of identifying or referring to goods/services is also not an infringement of trademarks, if it is done in a way that is purely descriptive, educational and does not damage the reputation of the brand. There must also be no confusion about us being in a brand relationship with any of these brands. For example, a permissible use would be displaying the Nike logo on a slide titled "Case Study: Nike's Digital Strategy". (This is just an example, for your reference)

I would recommend that we limit to necessary use and don't use excessive amounts of branding in our materials or play entire marketing campaigns. However, making reference to brands and using their logos to identify their products is okay from a legal perspective.”

## Global resources and considerations {#global-resources-and-considerations}

As more content is localised for a global audience, we need somewhere to keep track of local preferences and any location-specific terms. I’m starting us off with learner vs student \- feel free to add what you need.

| UK | Ireland | US | S. Africa | Kenya | India |
| :---- | :---- | :---- | :---- | :---- | :---- |
| Learner | Student | Student | Student | Learner | Learner |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |

### US English

Quoting Sofia here: There is no one education system in the US. It can vary state to state, district to district. That filters down to the language — it’s deeply local. Take the below as a guide, but refer to the US team for localisation and market-specific information.

When preparing copy for UK or international audiences (that is, the vast majority of our content), unless the matter is mentioned below, please consult New Hart's Rules: The Oxford Guide to Style. 

If a particular spelling or hyphenation choice is not specified here, the version in the Oxford English Dictionary is to be preferred. Exceptions are international organisations, such as The John F Kennedy Space Center

In copy intended specifically for a US audience, US English should be used.

**Spelling:**

| Pattern/category | UK English | US English |
| ----- | ----- | ----- |
| \-ae/-oe → e | anaemia, paediatric, oestrogen, manoeuvre | anemia, pediatric, estrogen, maneuver |
| \-ce → \-se (nouns) | defence, licence, offence, pretence | defense, license, offense, pretense |
| \-ise/-yse → \-ize/-yze | organise, recognise, analyse | organize, recognize, analyze |
| \-ll/-l variations | fulfil, enrol, instil, skilful | fulfill, enroll, instill, skillful |
| \-ogue → \-og | catalogue, dialogue, monologue | catalog, dialog, monolog |
| \-our → \-or | colour, behaviour, flavour, honour | color, behavior, flavor, honor |
| \-que → \-ck | cheque | check |
| aluminium/aluminum | aluminium | aluminum |
| amongst/among | amongst | among |
| autumn/fall | autumn | fall |
| double consonant before suffix | travelled, travelling, labelled | traveled, traveling, labeled |
| dropping silent e | ageing, judgement, likeable | aging, judgment, likable |
| grey/gray | grey | gray |
| learnt/learned | learnt | learned |
| maths/math | maths | math |
| okay/OK | okay/OK | ok |
| practise/practice | practise (verb)/practice (noun) | practice (noun and verb) |
| program/programme | programme | program |
| spelt/spelled | spelt | spelled |
| storey/story | storey | story/floor |
| towards/toward | towards | toward |
| tyre/tire | tyre | tire |
| whilst/while | whilst | while |

**General rules:**

* \-or not \-our (*behavior, humor*)  
* \-ize not \-ise (*realize, recognize*)  
* single l in suffixes (*traveling, modeling*)

**Grammar and style:** 

* Collective nouns:   
  * Use singular: *The team are playing* → *The team is playing.*  
* Dates:  
  * *mm/dd/yyyy* → *01/14/2025.*  
  * *Month Day, Year* → *January 14, 2025\.*  
  * *Tuesday, January 14, 2025* (comma after weekday).  
* Time:   
  * Use 12-hour clock → *3:00 p.m.*, not *15:00.*  
  * Avoid phrases like *“half ten,” “half past”* and *“quarter to/past.”* Use exact times, instead.  
* Temperature:  
  * Use Fahrenheit rather than Celsius.  
* Quotation marks:  
  * Use double quotes (“ ”); singles only inside doubles.  
  * Punctuation (.,) always inside quotes → *She said, “Let’s go.”*  
* Oxford comma:   
  * Always use: *red, white, and blue.*  
* Numbers:  
  * Always use commas for four-figure or larger numbers i.e., 1,500.  
* Capitalization for titles:  
  * Use capitals for job titles outside RPF.  
  * *Mr.*, *Ms.*, *Dr.* (with period).  
* Latin abbreviations: *e.g.,* and *i.e.,* — always with commas.  
* School terminology: *students* not *pupils*; *learning management* (not *classroom management*, except where appropriate); *principal* not *headteacher*. See more in the tables below.

**Time zones**

There are four main continental US time zones, plus Alaska and Hawaii–Aleutian time. Daylight Saving Time (DST) applies in most US states except Hawaii and most of Arizona (the Navajo nation does observe DST). **The US generally begins DST earlier and ends it later than the UK, so check the dates during March and late October/early November to ensure time conversions are correct.**

| Time zone | Offset/DST |
| ----- | ----- |
| PT – Pacific Time | UTC −8:00/−7:00 |
| MT – Mountain Time | UTC −7:00/−6:00 |
| CT – Central Time | UTC −6:00/−5:00 |
| ET – Eastern Time | UTC −5:00/−4:00 |

**Tone of voice and phrasing:**

Aim for friendly, direct, and conversational.  
Avoid overly formal or indirect phrasing. You don’t need to be as polite as in British English. (Though Sir/Ma’am is still used in the South and considered polite, especially in service situations or formal environments, but is formal or even stiff in other regions).

| British phrasing | US phrasing |
| ----- | ----- |
| How might you… | How could you…/Can you… |
| In order to… | To…/So… |
| May I/you may… | Can I/you can… |
| “Would you mind…”, “Perhaps you could…” | “Can you…”, “Please…” |

**Relevant vocabulary:**

| British English | US English |
| ----- | ----- |
| apartment | flat |
| at the weekend | on the weekend |
| **at university** | **in college/at college** |
| autumn | fall |
| bin/rubbish | trash can/garbage |
| car park | parking lot |
| **coursework** | **classwork/assignments** |
| **do an exam/sit an exam** | **take an exam** |
| fortnight | two weeks |
| full stop | period |
| **get a mark** | **get a grade** |
| ground floor | first floor |
| half ten | half past ten, 10:30 |
| have a go | try/give it a try |
| have a look | take a look |
| have a think | think about it |
| **headteacher** | **principal** |
| **holiday** | **vacation** |
| in a team | on a team |
| in future | in the future |
| **lesson** | **class** |
| lift | elevator |
| lorry | truck |
| **mark (a test)** | **grade (a test)** |
| minutes/data/contract (for phone) | data plan |
| mobile phone | cell phone |
| motorway | highway |
| **on holiday** | **on vacation** |
| petrol | gas/gasoline |
| post | mail |
| postcode | zipcode |
| postman/postwoman | mailman/mailwoman |
| **primary/secondary school** | **elementary/high school** |
| queue | line |
| **revision (for exams)** | **studying/review** |
| semi-detached house | duplex |
| **staffroom** | **teachers’ lounge/break room** |
| **term** | **semester** |
| terraced house | townhouse/row house |
| **tic-tac-toe** | **noughts and crosses** |
| **timetable** | **schedule** |
| toilet/loo | bathroom/restroom |
| town/city centre | downtown |
| wardrobe | closet |

**School system:**

| Level/exam | Typical ages | Grades/qualifications | Notes |
| ----- | ----- | ----- | ----- |
| **Elementary school** | 5–11 | Kindergarten to grade 5 (K–5) | Focus on core subjects such as reading, writing, maths, and science. |
| **Middle school/junior high** | 11–14 | Grades 6–8 | Transitional stage between elementary and high school; broader curriculum. |
| **High school** | 14–18 | Grades 9–12 | Students work toward a high school diploma. Years are known as freshman, sophomore, junior, and senior. |
| **High school diploma** | 17–18 | Awarded after grade 12 | Required for graduation; based on coursework and state requirements. |
| **SAT/ACT** | 16–18 | Standardised tests | Used for university admissions; not mandatory in all states. |
| **AP (advanced placement)** | 16–18 | College-level courses and exams | Can earn university credit for high-scoring students. |
| **PSAT** | 15–17 | Practice exam | Preliminary SAT, also used for scholarship eligibility. |
| **State standardised tests** | 5–18 | Varies by state | Assess progress in core subjects such as reading, maths, and science. |
| **GPA (grade point average)** | 14–18 | 0.0–4.0 scale | Cumulative average of grades; used in university applications. Can exceed 4.0, just don’t ask me how or why. |

**Cultural differences to note for UK editors**

* There is increased wariness about screen and AI technology use in US education (more so than in a UK context). Be aware that some terms may need adapting:  
  * Use ‘facial detection’ instead of ‘facial recognition’ (particularly for US Code Club projects).   
* Everyday tech/apps:  
  * WhatsApp/app-based instant messaging is not common. Text is preferred.  
  * Chip and pin is rare; cards are swiped and then the receipt signed. Contactless is increasingly available, but often used via Apple or Google Pay. Bank transfers are not available, so apps like Venmo are used (“to Venmo” is a verb). Check (cheques) is still used.  
  * Tipping is basically mandatory in food service.  
  * Taxes are not included in food prices at a grocery store, but added at checkout. The tax on goods varies from state to state.  
* Transport and travel:  
  * Comprehensive public transport is rare outside major cities. School buses are common, but young people may not be very familiar with the process of getting a public bus or train. Driving very long distances is more common than in the UK.  
  * Flights are often expensive (no low-cost carriers\!), so don’t assume all young people have been on a plane. Similarly, don’t assume all young people have had the opportunity to travel abroad (including to Canada/Mexico).  
* Talking about EDI/DEI and disability:  
  * Externally, EDI is known as DEI in the US.  
  * “Handicap” is still sometimes used and not considered as offensive as in the UK, but should be avoided. Refer to the EDI style guide for person vs disability first language, but use disability, disabled and accessible as relevant.  
  * “Handicap spot/space/parking” should be changed to “accessible parking space” or “reserved parking.”  
  * Different states have different approaches to talking about EDI/DEI — terms that are  common in the UK or seem neutral may be controversial in some states. Check with US learning managers if unsure.

### South African English (SAE)

“South African English (SAE) blends British English with local languages like Afrikaans, Zulu, and Xhosa, creating a unique linguistic tapestry. Distinctive pronunciations, vibrant vocabulary (e.g., braai, lekker), and idiomatic expressions (e.g., just now, shame\!) reflect South Africa’s cultural diversity and history, celebrating unity in diversity through language.”  
From: [https\://the-english-nook.com/2024/12/13/british-english-vs-south-african-english-celebrating-the-multicultural-voice-of-south-africa/](https://the-english-nook.com/2024/12/13/british-english-vs-south-african-english-celebrating-the-multicultural-voice-of-south-africa/)  
Which is a great primer for anyone unfamiliar with SAE, but no help with the specifics of UK vs US spellings unfortunately. 

For the most part, SAE follows UK English grammar and spelling, e.g:

* SAE uses ‘s’ where US English uses ‘z’ (organisation, etc.)   
* SAE uses \-our (behaviour, colour, etc.)  
* SAE uses two l’s not one (modelled, etc.)  
* SAE uses \-ogue endings (analogue, dialogue, etc.)  
* SAE uses ‘c’ for an ‘s’ in nouns such as licence  
* [More examples here](https://andreapaulsen.com/2023/10/04/english-spelling-why-different-options/)

There’s a few words where both options are used, so pick one and stick with it:

* **advisor** (preferred) or adviser  
* **focused** (preferred) or focussed  
* judgment or judgement  
* enquiry or inquiry

There’s a greater difference when it comes to word choice and commonly used terms, however. I love these. In addition to local languages, there’s a significant Dutch and Germanic influence in SAE, so if you’re familiar with these languages some of the slang will feel very familiar to you.

| UK/US word | SAE  |
| :---- | :---- |
| Garbage (US) | Bin |
| Yes | Yebo |
| Barbecue | Braai |
| Sausage | Boerwoers |
| Traffic light | Robot |
| Truck (pick-up type, I assume) | Bakkie |
|  | Diarise (to put something in your diary/calendar) |
| Team (sports) | Side |
| Meeting/conference | Indaba |
| To call someone | Tinkle (I’ll give you a tinkle) |
| Good/great/cool/tasty/basically any descriptor for a positive attribute | Lekker |
| Tasty food | Stunning food (can also be lekker) |
| Corn on the cob | Mealie |
| A deep-fried, sweet treat | Koeksister |
| Open countryside/grassland | Veld |
| Trousers | Pants |
| Jumper | Jersey |
| Trainers | Trekkies |
| Wellies | Gumboots |
| Crisps | Chips |
| Pop/fizzy drink/soda/etc. | Juice (used for any soft drink, fizzy or not) |
| Football | Soccer |

More examples here, including ones we’re less likely to need: [https\://joburgexpat.com/2012/07/09/my-43-favorite-south-africanisms/](https://joburgexpat.com/2012/07/09/my-43-favorite-south-africanisms/)

## Links {#links}

[Check the ‘Writing good descriptive link text’ guidance](https://docs.google.com/document/d/1Ap-btsPyDg4ZbYAUMoUwEvegKe5YHkUW-TK0ZhCviIE/edit?usp=sharing) for more info.

* Use ‘select’, ‘go to’, ‘visit’, ‘open’, or other general terms for visiting links, and **avoid ‘click’**, which is device-specific  
* For calls to action, start with an active verb (e.g. when you [open MakeCode](https://makecode.microbit.org/#editor))  
* If links on a page lead to the same destination, use the same linking text   
* Don’t use quotation marks to enclose links, just use descriptive text (sentence case) for the link, so it makes sense out of context: 

  [Visit the Apple accessibility page](https://www.apple.com/uk/accessibility/ipad/) to learn more.

  Either [download this Venn diagram template](https://docs.google.com/drawings/d/1_5M9hZ0vk7Op-WhYNz-b_psOAN-J6eMrwUmXuYmO9nY/edit) or …

* If the link leads to an organisation’s website, match the capitalisation to the org’s name:

  Organisations like the [AI Now Institute](https://ainowinstitute.org/our-work) advise …

* If the link leads to an item that has a title, offset this using single quotation marks or italics (according to the [‘Titles’ section of house style](#titles)):

  [Read the *Accessibility and me: Rani Nayyar* blog post](https://accessibility.blog.gov.uk/2017/09/19/accessibility-and-me-rani-nayyar/).

## URLs {#urls}

Omit [http\://www](http://www/) from URLs in print. Use hyperlinks in online content.

Make sure text hyperlinks are clear and make sense out of context, e.g. the June employee survey is now ready for your feedback. If possible, the hyperlink text and title of the webpage should be the same. This helps our SEO.  

# Punctuation {#punctuation}

Oxford **commas** should be used throughout; they resolve ambiguity and should be used elsewhere for consistency. 

* We photographed the components, a sandwich, and a magnet. (Good)  
* I’d like to thank my parents, Morgan Freeman and God. (Bad)

Do not use **ampersands** (&); always use 'and'. The exception might be in a print article for one of our magazines, where space is at a premium. Clubs workshop titles are another exception as they can run long (see above for examples).

Apostrophes (‘)

* Do not use apostrophes in abbreviated plurals: PCs, BGAs.   
* Apostrophes may be used when an abbreviation is turned into a verb, although it is best practice to avoid doing this altogether: My mother won't stop IM'ing me.  
* Plurals of letters should have apostrophes to avoid confusion — e.g. a’s and b’s.  
* Plurals of binary numbers should not have apostrophes — e.g. 0s and 1s (see ‘Binary’ for more details about references to binary numbers).

Do not use **forward slashes** to mean ‘instead of’ or ‘or’. E.g. use school or college, not school/college.

Fragments (e.g. for definitions) do not take a full stop at the end. E.g. An isolated or incomplete part of something

## Hyphen (-): {#hyphen-(-):}

* Try to use hyphens as little as possible. Use in post-16, cross-curricular, self-assessment and self-evaluation, or when it would be ambiguous e.g. seaweed-eating sheep.  
* Do not use in the words A level, email, or online.  
* Do not hyphenate adjectival compounds that begin with adverbs ending \-ly. A gorgeously constructed computer.  
* Add a hyphen on the end of multiple items that are joined to another word in this way. A 12- and 15-month subscription, full- and part-time jobs.  
* Hyphenate two or more modifiers before a noun unless the first adjective modifies the complete noun phrase. The moderators are fascist-robot enthusiasts. The moderators are fascist robot enthusiasts.  
* Consult en dash rules for more complex hyphenation cases.

## En dash (–): {#en-dash-(–):}

* Generated by \&ndash; or Alt+0150.  
* Use a closed-up en dash to form compound words either when one of the components is itself a hyphenated word, or when one of the components is formed of two words. Raspberry Pi–powered, e-book–only publisher, public school–educated student, liberal–conservative debate.  
* Use a closed-up en dash when expressing a connection, relation, or alternative. Dover–Calais crossing, Williams–Navratilova match.  
* Use a closed-up en dash when writing ranges. 7–17, Monday–Friday, \*\***although use “to” wherever possible, e.g. 21 to 23 January**.\*\* See ‘Numbers’ for more information.  
* Use for quote attribution (see quotation marks section).

## Em dash (—): {#em-dash-(—):}

* Generated by \&mdash; or  Alt+0151.  
* Use a pair of em dashes with space either side for making a parenthetical statement in the middle of a sentence. Em dashes express a more pronounced break in the sentence than commas, and also draw more attention to the parenthetical. They express less of a break than parentheses, and are more informal.   
* If using punctuation in the parenthetical, the closing dash may only be preceded by an exclamation or question mark and the following word may not be capitalised, even if it begins a sentence (unless it is a proper noun). E.g. The party lasted — we knew it would\! — far longer than planned.  
* Do not overuse em dashes.

## Quotation marks (' and "): {#quotation-marks-('-and-"):}

* Do not use ‘scare quotes’ (quotation marks put around a word or phrase in a written sentence in order to show that the word is being used in a special way, or in a way that may not be correct or true). Scare quotes make for vague, sensationalist writing. You can write better than that.  
* Use single quotes to highlight a word/phrase when needed, such as when you introduce a new term, or need to offset a title. E.g. “Ask what the word 'system' means” or “Hand out the ‘Bicycle system’ activity sheet.” However, be judicious in your use of quotation marks in this way: if the word/phrase stands out to the reader without them, leave them out; if the reader might stumble over the word/phrase without them, put them in.  
* Stylised quotes (‘’) are fine in curriculum documents using the Quicksand font because they go nicely, but they should not be used on the Ada platform.  
* Use double quotation marks only to indicate actual quoted speech or text. There is no need to add italics as well – the double quotes are enough.  
* In large sections of quoted speech, put double quotation marks at the end of each paragraph rather than omitting them, as per the Oxford Guide to Style.  
* Punctuating a **quote used in text**:  
  If the quoted text is a full sentence, it should have a capital letter and full stop within the quotation marks, even if it is introduced halfway through a sentence. E.g. According to Thomas Edison, “Genius is one percent inspiration and 99 percent perspiration.”  
  However, if you are quoting a fragment of a sentence or just a few words, there’s no capital and the full stop goes outside the quotation marks. E.g. Thomas Edison declared that genius was “one percent inspiration and 99 percent perspiration”.  
  Consider the following example, which demonstrates nicely why the full stop should be outside the quote: General Sedwick’s last words to his worried staff were “Don’t worry, boys; they couldn’t hit an elephant at this dist–”.   
* For **pullout quotes**, use an en dash and a space before the speaker's name, and put the attribution on a new line if space allows. Use commas to separate e.g. the speaker's name, role, and location.

“Prose writers are interested mostly in life and commas.”  
– Ursula Le Guin

“My learners are really enjoying the lessons… They keep asking, ‘Teacher, when are you having computer classes?’”  
– John Pierce, teacher at Mwingo Academy Primary School, Kenya

## Colon: {#colon:}

* When a colon is used in free text, the letter following the colon should be lower case. E.g. I have three dogs: a small one, a medium one, and a big one.  
* When a colon is preceded by a header-style construction, the letter following the colon should be upper-case.   
  E.g. Note: This wouldn’t look so great with a lower-case t.

## Capitalisation {#capitalisation}

The first word in **chapter headings and titles** take an initial capital, others lower case. (Sentence case.) In all text, try to avoid the use of a trademark whose initial letter is in lower case (iPad, element14) at the start of a sentence or title. iPad sales soar is only ever acceptable if typography means that there is insufficient space for Sales of iPad soar.

**Units** named after people do not require capitals (newtons, ohms, kelvin, etc.), although the symbol for the unit normally will be a capital. For example, room temperature is generally accepted to be 298 kelvin, but 0℃ is always 273K. 

This is important to avoid confusion between units such as Jkg\-1 (joules per kilogram, unit of entropy) and JKg\-1 (joules per kelvin gram, an odd and badly written but possible unit of heat capacity). 

Of course, it’s never that simple and degrees Celsius is the exception to the above rule as Celsius always takes a capital. Don’t ask me why.

See the [NIST website](https://physics.nist.gov/cuu/Units/units.html) for a fairly comprehensive list of named units, their symbols, and definitions. They also have a [page for prefixes](https://physics.nist.gov/cuu/Units/prefixes.html) (mega-, giga- etc.), which is also useful.

As a general rule with **software** in particular, check the manufacturer's capitalisation style. Many examples of software title capitalisation are in the word list below; if you encounter more, please contact Jan or Sarah to have them added to the list (or add them yourself while we’re keeping the style guide as a Google doc).

Use lower case for **subjects**, e.g. computing, computer science, mathematics, with the exception of English, French etc. But, use upper case for names of specific **qualifications** e.g. BTEC Level 2 Applied Science.

## Contractions {#contractions}

Simple, positive contractions can be used (e.g. it’s, that’s, we’re, I’m, etc.)

Avoid the following, which may be complex for people whose first language is not English: 

* Conditional contractions (should’ve, would’ve),   
* Uncommon contractions (mustn’t)

Note: It’s generally okay to use negative contractions, but try to avoid them in contexts where comprehension is key (e.g. online courses, CCP content).

# Formatting {#formatting}

## Lists {#lists}

Use semicolons for lists with internal commas. We received bouquets from Chris, in California; Jim, in Belgium; and Bob, in Liverpool.

Complicated lists are usually better presented typographically with bullets or numerals. Bullets should be used for lists of items with no hierarchy, numerals for lists of items with hierarchy, and for steps in a process (for example tutorials). Letters should never be used for list points. Bullet points take a capital letter but no full stop (this includes the final list item) unless one or more of the bulleted list items is made up of more than one sentence, in which case all points on the list should have a full stop, even if they are fragments.

A bulleted list should be introduced with a colon:

* First list item  
* Second list item  
* Third list item

See Titles of other works below for more examples of bulleted lists.

**Markdown specific**  
Lists should only be used for step-by-step instructions, not for ordinary paragraphs that don't contain specific instructions. When creating numbered lists, start each item with '1.', rather than ascending numbers. This makes it easier to add steps later without having to change all the others.

## Headings {#headings}

**Markdown specific**  
The main header should be formatted as h1, sub-headers as h2. Any further sub-headers in the hierarchy should be h3, h4 and so on. Never use bold formatting instead; likewise, never use headers to make text bold. Leave one line break between headers and the main ext. More info here: [Markdown Cheatsheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet)

## Titles {#titles}

### Titles of our works

* [Titles of education resources  ](https://docs.google.com/document/d/1-GpoN79qH4k1ujZU3qXNwFaqpe9XSqn0Q_p7Im38nEM/edit) (old, but still useful)

### Titles of other works

Titles of other works should be set in title case. Title case takes:

* First and last words with an initial capital, regardless of length of word or part of speech  
* All other words in the title also take a capital, except articles, prepositions of three or fewer letters, conjunctions of three or fewer letters, and the words if, how, and why

Here Is an Example of Title Case if You Need One

Treatment of the titles depends on the type of work. In general, titles should be set in italics.

Italicise the titles of the following types of works: 

* Artworks   
* Books, book chapters, and other parts of books   
* CDs, albums, songs   
* Lectures   
* Magazine and newspaper articles (BUT NOT the names of the magazines or newspapers themselves)  
* Titles of individual blog posts (unless the blog publishes posts under a date only), BUT NOT the names of the blog  
* Films, DVDs, operas, plays   
* Podcasts and episodes of podcasts   
* Poems   
* Speeches with titles   
* Television and radio programmes and episodes   
* Web shows, webinars, and online videos

Do **not** italicise the following:

* Games, e.g. computer games, board games, card games, arcade games  
* Software  
* Websites  
* Magazines  
* Newspapers  
* Blogs

But wait\! There's more\!  
If compiling a numbered or bulleted list of titles which are like items, the titles do not need to be set in italics because they do not need to stand out from surrounding text.   
Jemima's favourite old movies are:

* Gone With the Wind  
* Singin' in the Rain  
* The Third Man

A similar list of titles which are not like items should be set in italics where they are required.  
These are a few of my favourite things:

* Sausages  
* Banditry  
* *Anne of Green Gables*

## Abbreviations {#abbreviations}

Spell out abbreviations in the first instance in a chapter section, followed by the abbreviation in parentheses. Thereafter use the abbreviation. Raspberry Pi's brain is a system on a chip (SoC), made by stacking a memory chip on top of a processor chip. Using an SoC keeps the area of the Raspberry Pi board low.

Abbreviations should \*\***not**\*\* be marked in this format: \*\***S**\*\*ystem \*\***o**\*\*n a \*\***C**\*\*hip.

The full term should **\*\*not\*\*** have capital letters unless it contains a proper noun.   
E.g. NASA when spelt out would be capitalised (National Aeronautics and Space Administration is it’s name).  
But ML when spelt out does not need capitals (machine learning is not a proper noun). 

See the word list for correct abbreviations and their capitalisations when spelt out.

# Numbers {#numbers}

## General {#general}

In general, use numerals (1, 2, 3, etc.) rather than words (one, two, three, etc.) as this is easier for comprehension. For example: 

* You will need 4 paperclips and 2 wires for this project.  
* You should add 15–20 examples to train your model.

However, if the number is in the main body of text in a longer or more formal piece (annual report, research paper, mid-paragraph in a blog post, etc.), then

* Use the word for numbers 1 to 12  
  * We visited three schools running Code Clubs.  
* Use numerals for 13 and higher  
  * Learners aged 13 and over can register for Astro Pi.  
* Use numerals if you have a mix of \<12 and \>12 in the same sentence  
  * Use 3 colours and duplicate each 25 times.  
* The number starts a sentence, then use the word  
  * Eighteen bagpipers were shown to the door. NOT: 18 bagpipers were shown to the door.

For numbers of more than four digits, use commas: 10,000, 100,000. Except: for NCCE, use a comma for numbers over 999 e.g. 1,001

For a range of numbers, try to keep a consistent format: coding clubs for children aged 9–13, Pioneers are aged 11–16, one to twenty. Use common sense: if following the style guide looks awful, (coding clubs for children aged nine to 13, one to 20), use a consistent format instead.

School grades (USA): Spell out first through ninth grade and use figures for 10th grade or higher. Try to keep a consistent format for ranges, as above.

Use the multiplication symbol × when required, not the letter x.

Subscript numerals (e.g. in chemical formulae) are fine in print, but not for online content. So CO2 online, CO₂ in print. Note from a chemist: This is so wrong on a chemical level, but I appreciate subscript numbers may not display correctly for every device and browser accessing the content. If it can be guaranteed to render on (every) screen correctly, subscripts should be used, but if in doubt, leave it out.

## Binary {#binary}

When talking about binary, refer to 0 and 1 (in numbers, rather than spelt out, and with no punctuation surrounding the numbers) — e.g. 0s and 1s (no apostrophe)

## Units {#units}

There should be no space between a value and its SI unit: 2m, 2kg, 2ohm. There should also be no space between a value and a unit of storage: 8MB, 8GB, 8TB.

Always use % with a number. The word percentage should be used in full. If required, percent when written is one word.

Units named after people do not require capitals (newtons, ohms, kelvin, etc.), although the symbol for the unit normally will be a capital.   
Celsius is the exception to this as it always takes a capital. See the Capitalisation section for more details or see the [NIST website](https://physics.nist.gov/cuu/Units/units.html) for a fairly comprehensive list of named units, their symbols, and definitions. They also have a [page for prefixes](https://www.nist.gov/pml/owm/metric-si-prefixes) (mega-, giga- etc.), which is also useful.

## Time and date {#time-and-date}

### Time

Use the 24-hour clock (except for targeted audiences, events and in printed materials). 

* Separate hours and minutes with a colon.   
* Include the appropriate time zone abbreviation.   
* E.g. 8:00 BST, 16:15 GMT, 12:00 (noon), 24:00 (midnight), etc.

Use the 12-hour clock in copy that specifically targets British or North American audiences (for example, a blog post about an event in New York, or a schedule for a Picademy in Cardiff). 

* Include the appropriate time zone abbreviation for North American events.   
* Use a full stop to separate hours and minutes.   
* Separate the time and 'am/pm' with a thin space in print, but no space online.   
* Use 12 noon or 12 midnight not 12am or 12pm.  
* E.g. 5am PDT, 8.20pm, 12 noon EST, 12 midnight, etc.

For events or time ranges:  
If the event is solely in the morning or afternoon, it does not require am or pm after each time, i.e. 9 to 10am (not 9am to 10am). When something starts in the morning and ends in the afternoon, it reads 10am to 4pm.

### Dates

Dates should be expressed as 21 Jan 2026 etc. to avoid confusion with month/day ordering for readers outside the UK. Abbreviate months thus: Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec.

If copy is specifically for a US audience, express the date in US style: mm/dd/yyyy or month day, year (e.g. 01/14/2025 or January 14, 2025). If the day of the week is included, use a comma after, e.g. Tuesday, January 14, 2025\.

An x-week period: hyphen between number and 'week'. A six-week period.

Season names should not be capitalised.

When referring to decades, use the eighties or the 1980s, but never the '80s. When referring to two decades, use the 1970s and 1980s, even though the 1970s and '80s more accurately shows how such dates may be read out loud. When the name of a decade is used to define a social or cultural period it should be written as a word.

Date ranges should be written as 25 to 26 November 2025 or 25 to 26 Nov 25\.

Do not use a comma in dates

Do not use th, nd, or rd after a number.

Leave out the day of the week in a date, unless needed for clarity.

# References {#references}

The four most commonly used in education/computer science/sciences — APA, Harvard, IEEE, and Vancouver — are included in [this guide](https://docs.google.com/document/d/1uwZSx3NJIBVkILw58dC0OvDphnpOjuf9jV3dwM3racw/edit). These are suitable for practically everything the Foundation publishes. However, note that the following shorter style is used for the reference list in Quick Reads: 

Author(s) (Year). Title. The CC short link

**Example:**

1 Young, C. and Perović, N. (2016). Rapid and Creative Course Design: As Easy as ABC? [the-cc.io/qr25\_3](http://the-cc.io/qr25_3)

2 ABC Learning Design: Sprint design your courses and programs in just 90 minutes. [the-cc.io/qr25\_4](http://the-cc.io/qr25_4)

3 Laurillard, D. (2012). Teaching as a Design Science: Building Pedagogical Patterns for Learning and Technology. [the-cc.io/qr25\_5](http://the-cc.io/qr25_5)

4 Pashler, H. et al. (2008). Learning Styles: Concepts and Evidence. [the-cc.io/qr25\_6](http://the-cc.io/qr25_6)

With references, remember: **consistency is key\!** It’s better to be ‘wrong’ but consistent, than ‘right’ some of the time, but inconsistent. People will notice if you change styles, but very few people have memorised the finer points of every style.

Consistency checklist – Main text:

* Is there a comma between et al. and the year?  
* Are multiple references separated with a semicolon?  
* Is “and” or “&” used consistently for multiple authors?  
* Are references in parentheses (Author, year)?  
* Are the references before the full stop?

Consistency checklist – Reference list:

* If there are multiple initials for authors, is there consistently a space/no space between them?  
* Is the year positioned and formatted consistently?  
* Are all book and journal titles in italic?  
* Is Ed./Eds. consistently capitalised?  
* Check there aren’t any commas in italic, especially after journal names.  
* Is there an en dash (–) in page ranges?  
* Is there a full stop at the end? 

### Frequently used refs

If you find any references that you think we’ll use a lot, pop them in here so we can just copy and paste the correctly formatted version into wherever it needs to be.

| Ref (notes) | APA | Harvard | Vancouver | IEEE |
| :---- | :---- | :---- | :---- | :---- |
| Big Book of Computing Pedagogy (I’m treating this as a book) | Hello World (2021). *Big Book of Computing Pedagogy*. Cambridge: Raspberry Pi Foundation. | Hello World, 2021\. *Big Book of Computing Pedagogy*. Cambridge: Raspberry Pi Foundation. | Hello World. *Big Book of Computing Pedagogy*. Cambridge: Raspberry Pi Foundation. 2021\. | Hello World, *Big Book of Computing Pedagogy*. Cambridge, UK: Raspberry Pi Foundation, 2021\. |
| Quick Reads (I’m treating these as reports with RPF as the author and NCCE as the publishing organisation – as agreed with James 28/1/22) | Raspberry Pi Foundation (year). *Quick Read: Subtitle*. National Centre for Computing Education. Link | Raspberry Pi Foundation, year. *Quick Read: Subtitle*. \[PDF\] Cambridge: National Centre for Computing Education. Year. Available at: link \[Accessed on date\] | Raspberry Pi Foundation, *Quick Read: Subtitle*. National Centre for Computing Education. Year. Link | Raspberry Pi Foundation, “Quick Read: Subtitle,” National Centre for Computing Education, Cambridge, UK, Year. Accessed: date. \[Online\]. Available: Link |
| Seminar proceedings By volume By chapter |  |  |  |  |

# Referring to ourselves {#referring-to-ourselves}

## The Raspberry Pi Foundation {#the-raspberry-pi-foundation}

When referring to the company, use "the Raspberry Pi Foundation" with the definite article, never "Raspberry Pi Foundation" on its own without the article. It's acceptable to omit the "the" on covers and in titles. 

"The Raspberry Pi Foundation" should always be used as the first instance in an article; "the Foundation" is fine subsequently. For less formal text, "Raspberry Pi" can be used, but cautiously, so as to avoid confusion with the computer company.

Other exceptions:

* On business cards, always use "Raspberry Pi Foundation", with no definite article.  
* Image sources for RPF images can be written as follows:  
  Image source: Raspberry Pi Foundation

"the leading education charity for digital skills" is an approved description of RPF used in media releases

For the Raspberry Pi Foundation team: Trustee, Member, founder, co-founder, Board of Trustees, group of Members. Other job titles as here: [https\://www\.raspberrypi.org/about/team/](https://www.raspberrypi.org/about/team/)

## Our charitable status {#our-charitable-status}

**UK** – The Raspberry Pi Foundation is registered with the Charity Commission for England and Wales. We can say that the Foundation is "a registered charity" or "UK registered charity 1129409".  
For design assets, the current version is:   
Raspberry Pi Foundation, UK registered charity 1129409  
(no full stop)

**USA** – The Raspberry Pi Foundation North America is an official charity in the USA. According to the AP Stylebook, the only acceptable style is "501(c)(3)", and it can only be used as an adjective (501(c)(3) is the section of the US tax code that defines what a charity is). The consensus from a discussion with several US-based 501(c)(3) leaders was that it's best to refer to RPFNA as a nonprofit, rather than a charity. Therefore, at the bottom of flyers and similar assets used by RPFNA, we should include the line "The Raspberry Pi Foundation North America is a 501(c)(3) nonprofit”.

**India** – The Raspberry Pi Foundation is referred to as a "non-profit" rather than a "charity" in copy which specifically addresses an Indian audience, as "charity" can have negative connotations in India.

## Raspberry Pi computers {#raspberry-pi-computers}

"Raspberry Pi 4", "Raspberry Pi Zero", and so on; not "the Raspberry Pi 4" or "the Raspberry Pi Zero", and not just "Pi 4" or "Pi Zero". The plural of "Raspberry Pi" is "Raspberry Pis" (no apostrophe); but use "Raspberry Pi computers", "Raspberry Pi devices", etc. where possible.

Be careful with using Raspberry Pi 1 — the 1 is only necessary when you need to clearly distinguish it from other models. If you want to shorten the name of a model, do it like this: Raspberry Pi 2 Model B \> Raspberry Pi 2B

To check official nomenclature, refer to the [products page](https://www.raspberrypi.org/products/).

# Links, misc., and useful info  {#links,-misc.,-and-useful-info}

File names: e.g. \*.mp4 file

COVID-19 (not Covid or covid). 

- It’s short for COronaVIrus Disease  
- COVID-19 is the name of the disease caused by the virus [SARS-CoV-2](https://www.who.int/emergencies/diseases/novel-coronavirus-2019/technical-guidance/naming-the-coronavirus-disease-\(covid-2019\)-and-the-virus-that-causes-it), which is a member of the coronavirus family of viruses  
- Summary of AP style guidance for COVID: [https\://www\.poynter.org/reporting-editing/2020/ap-stylebook-tips-on-the-coronavirus/](https://www.poynter.org/reporting-editing/2020/ap-stylebook-tips-on-the-coronavirus/)

**Key stages and ages**   
Early Years Foundation Stage (EYFS) – ages 3-5 (Nursery and Reception)  
Key Stage 1 – ages 5-7 (Years 1-2)  
Key Stage 2 – ages 7-11 (Years 3-6)  
Key Stage 3 – ages 11-14 (Years 7-9)  
Key Stage 4 – ages 14-16 (Years 10-11)

**For US grades:**  
Spell out first through ninth grade and use figures for 10th grade or higher. Use figures in a range that includes 10th grade or higher.

* teacher of 9th–12th grade  
* teacher of seventh to ninth grade  
* In my fourth grade technology class  
* In my 10th grade technology class

## For reference {#for-reference}

* [Dictionary](https://dictionary.cambridge.org/)  
* [Thesaurus](https://www.thesaurus.com/) or [a different thesaurus](https://dictionary.cambridge.org/thesaurus/)  
* [Glossary of CS terms](https://docs.google.com/spreadsheets/d/1Xp3CXsDb_s50IaqNrl1-krZYmyjUHPj-J5KOCNyaxLU/edit#gid=0) (last updated June 2020\)  
* [Country names](https://www.gov.uk/government/publications/country-names) and [Geographical names index](https://www.gov.uk/government/publications/geographical-names-and-information)  
* [TCC naming conventions](https://docs.google.com/spreadsheets/d/1mBrVx1orTuMMCFukO5kbhyD8TQeO6wc7_-eJTma2IpQ/edit#gid=0)  
* [Isaac Computer Science Pseudocode Conventions](https://isaaccomputerscience.org/concepts/isaac_pseudocode?examBoard=all&stage=all)   
* [List of SI and named units, their symbols, and definitions](https://physics.nist.gov/cuu/Units/units.html)  
* [List of prefixes for units](https://physics.nist.gov/cuu/Units/prefixes.html)  
* [Five Steps to Plain Language](https://centerforplainlanguage.org/learning-training/five-steps-plain-language/) 

## To resources regarding accessibility and inclusion {#to-resources-regarding-accessibility-and-inclusion}

* [Ableism/Language](https://www.autistichoya.com/p/ableist-words-and-terms-to-avoid.html) (glossary of ableist phrases)  
* APA Style Guide index for articles on [Bias-free language](https://apastyle.apa.org/style-grammar-guidelines/bias-free-language)  
* [The Conscious Language Newsletter](https://consciousstyleguide.com/) – Monthly newsletter, style guides covering terminology for various communities, and links to key articles debating usage  
* [The Radical Copyeditor](https://radicalcopyeditor.com/) – Blog posts focusing on use of inclusive language and avoiding oppressive stereotypes  
* [Removing harmful language from my lexicon](https://www.duncannisbet.co.uk/removing-harmful-language-from-my-lexicon) (alternative terms in computing)

## To individual articles on inclusive language: {#to-individual-articles-on-inclusive-language:}

* [I am Disabled: On Identity-First Versus People-First Language](https://thebodyisnotanapology.com/magazine/i-am-disabled-on-identity-first-versus-people-first-language/)  
* [Autistic People Speak About Person-First Language](https://www.buzzfeednews.com/article/emersonmalone/autism-neurodivergent-people-language)  
* [Identity-First Language](https://autisticadvocacy.org/about-asan/identity-first-language/)   
* APA Style Guide article on using [Disability language](https://apastyle.apa.org/style-grammar-guidelines/bias-free-language/disability) 

[image1]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWwAAABsCAIAAADBih9aAAAIiElEQVR4Xu3auXEbSxSFYWUCkzHQVgT0IZY8ZUFGQF+FKjpy4cpmFX0EwHAepmfru3RPAxekBnj/VzKkWXrvg8FA3zYAEPBNHwCAUxAiAEIIEQAhhAiAEEIEQAghAiCEEAEQQogACCFEAIQQIgBCCBEAIYQIgBBCBEAIIQIghBABEEKIAAi5iRB53h8m+yd5brt7m8697x7lSQBhNxEig5QXOkRGXdAQIsDlESIAQggRACFrC5HKK4yn7M2HGwdnhcjj7t0vtqtu/7zZ/p7O66JFg35vyyf1jcAtWVOI9Pv5bTdux+1uP/49vTqdNmq/sY87XDojRJ72c3X9vp+uGVNguCAVri+eK3vaZ4WnjkytVVcCN2ZFIdJttmyXZmw66C09HyztVj9EJLH5097PqxAl1OoyHekOmEcV4EasJ0TKO01+sPfSw4jaxLWN3RQiog2mPakZ0+PP8KDiVGdurDcMuHLFEMm/0x+87ZSR+yP/XxsH+7xQILeo4J1KIaJCobpXCyGSvfIYNIbIRt47X6kHZ1RqmFQbdvHCqCPG5LxhB8KKIfLlzKadmN27udCTiHm3csKTSGbY28UbgZu2nhBxX3P0bDrYI6WDIydEbI21EPFia5JXXW0GcHPWEyLjA/m8/fSvM9NTgPddpjtc271OiPTfHcaD49cQP0T0exnxs44+K39LAm7bmkJkU/lfG+o7v4gK9R6hNySO+4Yi/xV5fstwLFM/ieT0FxlZcv2s7gtwQ1YWIiuiv84AcBEiJYQI0IQQKSFEgCaESAkhAjQhRACEECIAQggRACGECIAQQgRACCECIIQQARBCiAAIIUQAhBAiAEIIEQAhhAiAEEIEQAghAiCkFCI/718+frxmf17+3E0nH/6KU68f3x/mO+9+HeTZw/39fBbAjSFEAISUQgQAmhAiAEIIEQAhhAiAEEIEQAghAiCEEAEQQogACCFEAIQQIgBCCBEAIYQIgBBCBEAIIQIghBABEHJ+iDztD0fvv7f6RMVzuqe3f9Jnr89295a68qxPLDpn9C7lcfd+VptxjjTa/2q5d8vsbffZi6wSIl0DKqu8sg2Wmp723r8Z1cv6X4TI0mxeje3vrt8XX3YLxV5RiJy4MCbnh0jFUtO/LET6reo4r1834sS1sjSbV2Nht5/rk4q9iNPm7sSFMbntEJmteaa/2olrZWk2r8YnrYFPKvYiTpu7ExfGxAmRNCiOKVDyz3dR5fDkZuhulENk4aVJqlmX1sSf6a66991j3iNxjXiSEWeGLzJJV0Kuu+t4cTYa+SgVR69vZNe7+RId4vn4DEynfPqhrNSkubyW2RTtaWtJKlb1K81ONoyi6rZia3TfR3JGs2Wvh91vz1Kx+V1m0dYXiVxgA92qAr1/RdWiWHdH55YXSeKEyKi7q9bucm4t5Z8fInIlpTara4Ylqzdti3KI5IOSGja2/HjL3Lt+sk0BUwzlxuEeC1U7pOeN3jj948WpefM14p+pktogZ9S+lVUvdrM4m8eL5yv71WkHyBKDPB+ZbrWtbSm1gb8GErHabAOq7akU23MHsLpI9DoUy6BKbRtV9dM+W4dpOYkN7q3JXn2RrCdETHXO/jxl50j+TJtx9C9LvFRzG9lfqT9X9UB5B81yEWOiRtXPJo+eDq/qie2mvr1ERV6ZbrlqjzekF1GcXDMg4sql9hSLHbkDWFskuj12Tgr0jX7VI5Pm5vYS1aDVhIidqnL5Z/Bnunndb2ol6BWmu+92xDtoqsinQE+5ubjEzKNX9cQWq7tTUi1WEk3SNaZy7KjG6Yoqx/NpXWqPc7vkDqA+mI+eXpZmBgtsS3Qtkj7bPIOqorWESGqWwy3/DHZ8O3q2lBS4sjleCXp56e67A+UdNI2UU2C/zpjmeMw86qoXuqm7k3HufNbXuLIyu8VglllecFMnW5jhHdheJPm01tpTKnbiDqA+KCbFfp3Ra8xlW+LWIpizhRm0g7S+EHF34wXZ8e3UQiSN2uInv9ds3X13oLyDpgoxBTpnTVsKzDyKqpe7qbuTHy89kC+axq27Sw/gLE1Qe1frbNfqxx1eexZvdwdQH7STMiuPj2RbImrpEyQ7X21DbmGRVELE2+q5YpW6DsMruVxaRnemnd+kSoiYU+US9Bw3zY130FSR73+TBa30aPcrdKi6oZv2SJKKyQ97PSobHkC6wusT6oxw/xK3va6RU1T1uMtebI9Iej24B7PRKwx4A9WSPjXGWlKxop26DaU1trRIKiHSL5Py6FQWTarVac1AL+veQnWb6XOgek2BPzFmdGYytsePBrcE3R49N+5AeQdNI/NJ9QetRb560qZ9n6tu6aY/m/1OHq8cpkb3qCK1ZL9/07ds8x8CnKwa22wOLzMfxSPZF6m1Pf7dHb0e3IP5evAWVZu8dWnxvGUZLeZxCGLZsMI4LC2SWojMNSX5R6KhK04LdzQ21L/zuXDXwQ59KkAfbGL2Z1IJkc28MQ6p76KEaR3n8m6W1kdhDPpiTSPzEHErbV1qc61d8d2/5l5XujlyZ1P05XjQi8WaoTu6ro0aI2e6z30S2YjOqqr1xGQnl9rjF6sXczLNZnWRmMYc3HHyzIukWxspqeda8iYd69Jt6IiaGxdJPUSwGs7HXeFzA1cu7WP7jck+DK4FIXIlvIemtNoIkRsjfpoZpI8QQgQx9kmkf8IkQ26OeRLpHzlbv7p+PULkeph3Iue8FMA10O9E9JuLdSFEAIQQIgBCCBEAIYQIgBBCBEAIIQIghBABEEKIAAghRACEECIAQggRACGECIAQQgRASClEft6/fPx4zf68/LmbTj78FadeP74/zHfe/TrIs4f7+/ksgBtDiAAIKYUIADQhRACEECIAQggRACGECIAQQgRACCECIIQQARBCiAAIIUQAhBAiAEL+A0sc8dkRYoRCAAAAAElFTkSuQmCC>