# Source provenance — PlayGPT

Packaged for Mark Calleja on 6 November 2026.

Source GPT: https://chatgpt.com/g/g-swOtn8EHo

The prompt was copied from the author’s GPT configuration. Source text is preserved in system-prompt.md. The skill wrapper adds identifying metadata, reference links and host compatibility guidance. The original name, description, conversation starters and capability settings are recorded in original-configuration.json.

Knowledge attachments: 6. Original attachment bytes were checked against the export’s recorded size and SHA-256 hashes. Word document text copies are derived reading aids; the original files are retained.

Includes six original game documents and extracted text copies. Image charades needs an image-capable host; text games can run in an ordinary chat.

The package was structurally validated and its archive integrity checked. It has not been behaviour-tested on every model. Original claims, example quotations and bibliographies have not been independently fact-checked by this preservation pass. No new licence is asserted for Mark’s work; source documents retain their existing notices.
